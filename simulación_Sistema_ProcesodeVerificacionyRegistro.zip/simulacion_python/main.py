"""Simulación de la línea de recepción IoT conectada a papeleria_db (PostgreSQL).

Uso:  python main.py
config.py ya trae los datos de conexión; cámbialos ahí si tu servidor cambia."""
import os
import sys
import tkinter as tk
from tkinter import messagebox

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)


def aviso(titulo, texto):
    print(f"\n{titulo}\n{texto}\n", file=sys.stderr)
    r = tk.Tk()
    r.withdraw()
    messagebox.showerror(titulo, texto)
    r.destroy()


def main():
    if sys.platform.startswith("win"):
        try:    # texto nítido en pantallas con escala de Windows
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    try:
        import psycopg2
    except ImportError:
        aviso("Falta psycopg2", "Instala las dependencias con:\n\n    pip install -r requirements.txt")
        return 1

    import config
    from bd import BaseDatos

    destino = f"{config.BD['dbname']} en {config.BD['host']}:{config.BD['port']} (usuario {config.BD['user']})"
    try:
        bd = BaseDatos(config)
    except UnicodeDecodeError:
        aviso("No se pudo conectar", f"PostgreSQL rechazó la conexión a {destino}.\n\n"
              "Casi siempre es la contraseña o el usuario de config.py. (El mensaje del servidor venía en "
              "español con acentos y Python no pudo mostrarlo.)")
        return 1
    except psycopg2.Error as e:
        aviso("No se pudo conectar", f"No pude conectarme a {destino}.\n\n"
              "Revisa en config.py el host, el puerto, el usuario y la contraseña, y que el servicio de "
              f"PostgreSQL esté encendido.\n\nDetalle: {str(e).strip()}")
        return 1

    try:
        faltan = bd.tablas_faltantes()
        if faltan:
            aviso("Faltan tablas", f"La base {config.BD['dbname']} no tiene estas tablas:\n{', '.join(faltan)}\n\n"
                  "Corre primero papeleria_postgresql_v2.sql (viene en esta carpeta) en esa base.")
            return 1
        bd.preparar(os.path.join(AQUI, "preparar_simulacion.sql"))
        if not bd.catalogo(config.PROVEEDOR_POR_DEFECTO):
            aviso("Sin productos", f"El proveedor {config.PROVEEDOR_POR_DEFECTO} no tiene productos activos en "
                  "proveedor_productos. Revisa PROVEEDOR_POR_DEFECTO en config.py.")
            return 1
    except psycopg2.Error as e:
        aviso("Error al preparar la base", (getattr(e, "pgerror", None) or str(e)).strip())
        return 1

    from interfaz import App
    root = tk.Tk()
    App(root, bd, config)
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
