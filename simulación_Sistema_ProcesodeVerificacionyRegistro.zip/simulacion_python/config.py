# =====================================================================
# Configuración de la simulación. Ya trae tus datos de conexión: solo
# cámbialos si cambia tu servidor, tu usuario o tu contraseña.
# =====================================================================

# Conexión a tu base PostgreSQL papeleria_db
BD = {
    "host": "localhost",
    "port": 5432,
    "dbname": "papeleria_db",
    "user": "postgres",
    "password": 'Miercolesdeplaza1',
}

ZONA_HORARIA = "America/Mexico_City"

# Datos de operación que se guardan en la base
PROVEEDOR_POR_DEFECTO = "PROV-001"   # Norma
OPERADOR = "operador_1"              # va a operador_id, responsable_id y usuario_id
TURNO = "UNICO"                      # columna turno de movimientos_inventario

# Ubicaciones de tu tabla ubicaciones
UBIC_RECEPCION = "REC-01"   # banda de recepción, zona de espera y línea
UBIC_ALMACEN = "ALM-01"     # almacén principal
UBIC_REVISION = "CUA-01"    # zona de revisión humana

# Orden de ejemplo que aparece al abrir la simulación: (id_producto, cajas)
ORDEN_EJEMPLO = [("P-003", 6), ("P-001", 4), ("P-002", 4), ("P-016", 5), ("P-013", 3)]

# Velocidad inicial: milisegundos por paso de banda
VELOCIDAD_MS = 450
