"""Acceso a PostgreSQL. Cada operación del proceso es una sola transacción:
si algo falla, no queda nada a medias en la base."""
import uuid

import psycopg2
import psycopg2.extras

psycopg2.extras.register_uuid()
Json = psycopg2.extras.Json

# Tablas y vista que usa la simulación. Al arrancar se revisa que existan.
TABLAS_REQUERIDAS = (
    "proveedores", "productos", "proveedor_productos", "ubicaciones", "recepciones", "detalle_recepcion",
    "paquetes", "detalle_paquete", "dispositivos_iot", "eventos_iot", "ordenes_trabajo", "detalle_orden_trabajo",
    "movimientos_inventario", "existencias", "incidencias", "revisiones_humanas", "auditoria",
    "vw_existencias_disponibles",
)

# Opciones de la pestaña Base de datos: nombre que se ve -> (tabla real, consulta, lo más reciente primero).
# En «existencias» salen primero las cajas que se movieron al último (por ejemplo, la que se acaba de vender).
# «existencias» es la tabla paquetes. En la base se sigue llamando paquetes porque ya existe otra tabla
# existencias (el saldo por producto y ubicación). Se muestra con tres columnas de apoyo que no son de
# paquetes: id_producto y producto (de detalle_paquete y productos) y folio_recepcion (de recepciones).
VISTAS_BD = {
    "recepciones": ("recepciones", "SELECT * FROM recepciones ORDER BY fecha_recepcion DESC"),
    "detalle_recepcion": ("detalle_recepcion",
                          """SELECT d.* FROM detalle_recepcion d JOIN recepciones r USING (id_recepcion)
                             ORDER BY r.fecha_recepcion DESC, d.id_producto"""),
    "existencias": ("paquetes",
                    """SELECT p.epc_rfid, dp.id_producto, pr.nombre AS producto, p.estado_validacion,
                              p.id_recepcion, r.folio AS folio_recepcion, p.fecha_registro, p.id_paquete
                       FROM paquetes p
                       LEFT JOIN detalle_paquete dp USING (id_paquete)
                       LEFT JOIN productos pr USING (id_producto)
                       LEFT JOIN recepciones r USING (id_recepcion)
                       LEFT JOIN (SELECT id_paquete, MAX(fecha_movimiento) AS ultimo FROM movimientos_inventario
                                  WHERE id_paquete IS NOT NULL GROUP BY id_paquete) mv USING (id_paquete)
                       ORDER BY COALESCE(mv.ultimo, p.fecha_registro) DESC, p.epc_rfid DESC"""),
    "eventos_iot": ("eventos_iot", "SELECT * FROM eventos_iot ORDER BY fecha_evento DESC"),
    "incidencias": ("incidencias", "SELECT * FROM incidencias ORDER BY fecha_creacion DESC"),
    "ordenes_trabajo": ("ordenes_trabajo", "SELECT * FROM ordenes_trabajo ORDER BY fecha_creacion DESC"),
    "dispositivos_iot": ("dispositivos_iot", "SELECT * FROM dispositivos_iot ORDER BY id_dispositivo"),
    "productos": ("productos", "SELECT * FROM productos ORDER BY id_producto"),
}

# resultado de lectura -> (tipo_incidencia, severidad, accion_recomendada)
TIPOS_LECTURA = {
    "SIN_LECTURA": ("SIN_LECTURA_CODIGO", "MEDIA", "CAPTURAR_ID_MANUAL"),
    "FORMATO": ("ID_FORMATO_INVALIDO", "MEDIA", "CAPTURAR_ID_MANUAL"),
    "CODIGO_DESCONOCIDO": ("CODIGO_PRODUCTO_DESCONOCIDO", "ALTA", "CAPTURAR_ID_MANUAL"),
    "DUPLICADO": ("ID_DUPLICADO", "ALTA", "REVISAR_DUPLICADO"),
    "NO_ESPERADO": ("PRODUCTO_NO_ESPERADO", "ALTA", "DECIDIR_ACEPTAR_O_DEVOLVER"),
    "EXCEDENTE": ("CAJA_EXCEDENTE", "MEDIA", "DECIDIR_ACEPTAR_O_DEVOLVER"),
}
TIPOS_RFID = {
    "NO_COINCIDE": "EPC_NO_COINCIDE",
    "SIN_LECTURA": "EPC_SIN_LECTURA",
    "DUPLICADO": "EPC_DUPLICADO",
}


# ---------------------------------------------------------------------
# Ayudantes que trabajan dentro de una transacción abierta
# ---------------------------------------------------------------------
def _evento(cur, dispositivo, tipo, datos=None, epc=None, estado="PROCESADO"):
    """Registra un evento IoT. El id lo genera el 'gateway' (aquí, Python)."""
    ide = uuid.uuid4()
    cur.execute(
        """INSERT INTO eventos_iot (id_evento, id_dispositivo, epc_rfid, tipo_evento, fecha_evento,
               datos_originales, estado_procesamiento, fecha_procesamiento)
           VALUES (%s, %s, %s, %s, NOW(), %s, %s, CASE WHEN %s = 'PENDIENTE' THEN NULL ELSE NOW() END)""",
        (ide, dispositivo, epc, tipo, Json(datos) if datos is not None else None, estado, estado),
    )
    return ide


def _cerrar_evento(cur, id_evento, estado, extra):
    """Marca como PROCESADO o RECHAZADO un evento que esperaba confirmación y le agrega el resultado."""
    cur.execute(
        """UPDATE eventos_iot SET estado_procesamiento = %s, fecha_procesamiento = NOW(),
               datos_originales = COALESCE(datos_originales, '{}'::jsonb) || %s::jsonb
           WHERE id_evento = %s""", (estado, Json(extra), id_evento))


def _existencia(cur, id_producto, ubicacion, delta):
    cur.execute(
        """UPDATE existencias SET cantidad = cantidad + %s, fecha_actualizacion = NOW()
           WHERE id_producto = %s AND id_ubicacion = %s""",
        (delta, id_producto, ubicacion),
    )
    if cur.rowcount == 0:
        cur.execute("INSERT INTO existencias (id_producto, id_ubicacion, cantidad) VALUES (%s, %s, %s)",
                    (id_producto, ubicacion, delta))


def _auditoria(cur, entidad, id_registro, accion, usuario, anterior=None, nuevo=None, motivo=None):
    cur.execute(
        """INSERT INTO auditoria (entidad, id_registro, accion, usuario_id, valor_anterior, valor_nuevo, motivo)
           VALUES (%s, %s, %s, %s, %s, %s, %s)""",
        (entidad, str(id_registro), accion, usuario,
         Json(anterior) if anterior is not None else None, Json(nuevo) if nuevo is not None else None, motivo),
    )


def _incidencia(cur, tipo, severidad, motivo, accion=None, id_recepcion=None, id_paquete=None,
                id_producto=None, id_evento=None, esperada=None, detectada=None, estado="PENDIENTE"):
    cur.execute(
        """INSERT INTO incidencias (id_recepcion, id_paquete, id_producto, id_evento, tipo_incidencia, severidad,
               cantidad_esperada, cantidad_detectada, estado, accion_recomendada, motivo)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING id_incidencia""",
        (id_recepcion, id_paquete, id_producto, id_evento, tipo, severidad, esperada, detectada, estado, accion, motivo),
    )
    return cur.fetchone()[0]


def _revision(cur, id_incidencia, responsable, decision, observaciones, estado_incidencia="RESUELTA"):
    cur.execute(
        """INSERT INTO revisiones_humanas (id_incidencia, responsable_id, decision, observaciones)
           VALUES (%s, %s, %s, %s)""",
        (id_incidencia, responsable, decision, observaciones),
    )
    cur.execute("UPDATE incidencias SET estado = %s WHERE id_incidencia = %s", (estado_incidencia, id_incidencia))


def _estado_paquete(cur, id_paquete, estado):
    cur.execute("UPDATE paquetes SET estado_validacion = %s WHERE id_paquete = %s", (estado, id_paquete))


class BaseDatos:
    def __init__(self, cfg):
        self.cfg = cfg
        self.op = cfg.OPERADOR
        self.conn = psycopg2.connect(connect_timeout=5, **cfg.BD)
        self._seq_epc = None
        with self.conn, self.conn.cursor() as cur:
            cur.execute("SET TIME ZONE %s", (cfg.ZONA_HORARIA,))

    def cerrar(self):
        try:
            self.conn.close()
        except Exception:
            pass

    # ------------------------------------------------------------- arranque
    def tablas_faltantes(self):
        faltan = []
        with self.conn, self.conn.cursor() as cur:
            for t in TABLAS_REQUERIDAS:
                cur.execute("SELECT to_regclass(%s)", (t,))
                if cur.fetchone()[0] is None:
                    faltan.append(t)
        return faltan

    def preparar(self, ruta_sql):
        with open(ruta_sql, encoding="utf-8") as f:
            sql = f.read()
        with self.conn, self.conn.cursor() as cur:
            cur.execute(sql)

    def proveedores(self):
        with self.conn, self.conn.cursor() as cur:
            cur.execute("SELECT id_proveedor, nombre FROM proveedores WHERE activo ORDER BY id_proveedor")
            return cur.fetchall()

    def catalogo(self, id_proveedor):
        """Productos del proveedor con su numeración (codigo_proveedor)."""
        with self.conn, self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """SELECT p.id_producto, p.nombre, p.unidad_medida, pp.codigo_proveedor
                   FROM proveedor_productos pp JOIN productos p USING (id_producto)
                   WHERE pp.id_proveedor = %s AND pp.activo AND p.activo
                   ORDER BY p.id_producto""", (id_proveedor,))
            return [dict(r) for r in cur.fetchall()]

    # ----------------------------------------------------- utilidades internas
    def _nuevo_epc(self, cur, id_producto):
        cur.execute("SELECT to_char(NOW(), 'YYMMDD')")
        hoy = cur.fetchone()[0]
        if self._seq_epc is None:
            cur.execute("SELECT COUNT(*) FROM paquetes")
            self._seq_epc = cur.fetchone()[0]
        while True:
            self._seq_epc += 1
            epc = f"{id_producto}-{hoy}-{self._seq_epc:05d}"
            cur.execute("SELECT 1 FROM paquetes WHERE epc_rfid = %s", (epc,))
            if cur.fetchone() is None:
                return epc

    def _crear_paquete(self, cur, id_recepcion, id_producto, epc, id_evento, codigo, obs):
        cur.execute(
            """INSERT INTO paquetes (id_recepcion, epc_rfid, estado_validacion) VALUES (%s, %s, 'PENDIENTE')
               RETURNING id_paquete""", (id_recepcion, epc))
        idp = cur.fetchone()[0]
        cur.execute("INSERT INTO detalle_paquete (id_paquete, id_producto, cantidad_declarada) VALUES (%s, %s, 1)",
                    (idp, id_producto))
        self._mov(cur, id_producto, "RECEPCION", None, self.cfg.UBIC_RECEPCION, id_recepcion=id_recepcion,
                  id_paquete=idp, id_evento=id_evento, obs=f"ID proveedor {codigo}. {obs}".strip())
        return idp

    def _mov(self, cur, id_producto, tipo, origen, destino, id_recepcion=None, id_paquete=None,
             id_evento=None, id_orden=None, obs=None):
        cur.execute(
            """INSERT INTO movimientos_inventario (id_producto, tipo_movimiento, cantidad, ubicacion_origen,
                   ubicacion_destino, id_recepcion, id_paquete, id_evento, id_orden, turno, operador_id, observaciones)
               VALUES (%s, %s, 1, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (id_producto, tipo, origen, destino, id_recepcion, id_paquete, id_evento, id_orden,
             self.cfg.TURNO, self.op, obs))
        if origen:
            _existencia(cur, id_producto, origen, -1)
        if destino:
            _existencia(cur, id_producto, destino, 1)

    def _estado_recepcion(self, cur, id_recepcion, folio, nuevo, motivo):
        cur.execute("SELECT estado FROM recepciones WHERE id_recepcion = %s FOR UPDATE", (id_recepcion,))
        anterior = cur.fetchone()[0]
        cur.execute("UPDATE recepciones SET estado = %s, operador_id = %s, observaciones = %s WHERE id_recepcion = %s",
                    (nuevo, self.op, motivo, id_recepcion))
        _auditoria(cur, "recepciones", folio, "CAMBIO_ESTADO", self.op, {"estado": anterior}, {"estado": nuevo}, motivo)

    # ------------------------------------------------------ etapa 1: recepción
    def crear_recepcion(self, id_proveedor, documento, lineas):
        """lineas: [(id_producto, cajas)]. Devuelve (id_recepcion, folio). Estado BORRADOR."""
        with self.conn, self.conn.cursor() as cur:
            cur.execute("SELECT to_char(NOW(), 'YYYYMMDD'), (SELECT COUNT(*) FROM recepciones WHERE fecha_recepcion::date = CURRENT_DATE)")
            hoy, n = cur.fetchone()
            while True:
                n += 1
                folio = f"REC-{hoy}-{n:03d}"
                cur.execute("SELECT 1 FROM recepciones WHERE folio = %s", (folio,))
                if cur.fetchone() is None:
                    break
            cur.execute(
                """INSERT INTO recepciones (folio, id_proveedor, documento_proveedor, operador_id, estado, observaciones)
                   VALUES (%s, %s, %s, %s, 'BORRADOR', 'Descarga y conteo en curso') RETURNING id_recepcion""",
                (folio, id_proveedor, documento, self.op))
            idr = cur.fetchone()[0]
            for prod, cajas in lineas:
                cur.execute(
                    """INSERT INTO detalle_recepcion (id_recepcion, id_producto, cantidad_esperada, costo_unitario)
                       VALUES (%s, %s, %s, NULL)""", (idr, prod, cajas))
            _auditoria(cur, "recepciones", folio, "CREAR", self.op, None,
                       {"estado": "BORRADOR", "documento_proveedor": documento,
                        "lineas": [{"id_producto": p, "cajas": c} for p, c in lineas]},
                       "Llega el camión del proveedor")
        return idr, folio

    def conteo_ir(self, folio, conteo):
        with self.conn, self.conn.cursor() as cur:
            return _evento(cur, "IR-E1", "DETECCION_IR", {"recepcion": folio, "conteo": conteo})

    def fin_conteo(self, id_recepcion, esperadas, contadas):
        """Si el conteo IR no cuadra con lo esperado, crea la incidencia. Devuelve su id o None."""
        if esperadas == contadas:
            return None
        with self.conn, self.conn.cursor() as cur:
            return _incidencia(cur, "DIFERENCIA_CONTEO_RECEPCION", "ALTA" if abs(esperadas - contadas) > 2 else "MEDIA",
                               f"El IR de recepción contó {contadas} cajas y la recepción espera {esperadas}.",
                               "VALIDAR_CON_PROVEEDOR", id_recepcion=id_recepcion, esperada=esperadas, detectada=contadas)

    def aprobar_recepcion(self, id_recepcion, folio, id_incidencia):
        with self.conn, self.conn.cursor() as cur:
            if id_incidencia:
                _revision(cur, id_incidencia, self.op, "APROBAR",
                          "Se aprueba con diferencia. La línea valida el detalle por producto.")
            self._estado_recepcion(cur, id_recepcion, folio, "EN_PROCESO", "Operador aprueba la recepción")

    def rechazar_recepcion(self, id_recepcion, folio, id_incidencia, esperadas, contadas):
        with self.conn, self.conn.cursor() as cur:
            if not id_incidencia:
                id_incidencia = _incidencia(cur, "RECEPCION_RECHAZADA", "ALTA", "El operador rechazó la entrega.",
                                            "DEVOLVER_PROVEEDOR", id_recepcion=id_recepcion,
                                            esperada=esperadas, detectada=contadas)
            _revision(cur, id_incidencia, self.op, "RECHAZAR", "Entrega rechazada. Las cajas regresan al proveedor.")
            self._estado_recepcion(cur, id_recepcion, folio, "CANCELADA", "Operador rechaza la entrega")

    # ----------------------------------------------- etapa 3: lector de barras
    def deteccion_ir(self, dispositivo, folio):
        with self.conn, self.conn.cursor() as cur:
            return _evento(cur, dispositivo, "DETECCION_IR", {"recepcion": folio})

    def codigo_registrado(self, codigo):
        """EPC del paquete que ya tiene este ID de proveedor (sin contar devueltos), o None."""
        with self.conn, self.conn.cursor() as cur:
            cur.execute(
                """SELECT p.epc_rfid FROM eventos_iot e
                   JOIN paquetes p ON p.epc_rfid = e.datos_originales->>'epc'
                   WHERE e.tipo_evento IN ('LECTURA_CODIGO', 'LECTURA_CODIGO_MANUAL')
                     AND e.estado_procesamiento = 'PROCESADO'
                     AND e.datos_originales->>'codigo_barras' = %s
                     AND p.estado_validacion <> 'DEVUELTO'
                   LIMIT 1""", (codigo,))
            r = cur.fetchone()
            return r[0] if r else None

    def esperado_y_aceptado(self, id_recepcion, id_producto):
        """(cajas esperadas del producto en la recepción, cajas ya aceptadas)."""
        with self.conn, self.conn.cursor() as cur:
            cur.execute("SELECT cantidad_esperada FROM detalle_recepcion WHERE id_recepcion = %s AND id_producto = %s",
                        (id_recepcion, id_producto))
            r = cur.fetchone()
            cur.execute(
                """SELECT COUNT(*) FROM paquetes p JOIN detalle_paquete d USING (id_paquete)
                   WHERE p.id_recepcion = %s AND d.id_producto = %s AND p.estado_validacion <> 'DEVUELTO'""",
                (id_recepcion, id_producto))
            return (int(r[0]) if r else None), cur.fetchone()[0]

    def lectura_codigo(self, folio, codigo):
        """El lector de barras de E3 entrega un código. Queda PENDIENTE hasta que el IR que está
        después del lector confirme que pasó una caja."""
        with self.conn, self.conn.cursor() as cur:
            return _evento(cur, "LB-E3", "LECTURA_CODIGO", {"recepcion": folio, "codigo_barras": codigo},
                           estado="PENDIENTE")

    def lectura_ok(self, id_recepcion, folio, codigo, id_producto, id_evento):
        """El IR confirmó la caja y su lectura es válida: la lectura pasa a PROCESADO y se crea
        el paquete con su EPC y la entrada a recepción."""
        with self.conn, self.conn.cursor() as cur:
            epc = self._nuevo_epc(cur, id_producto)
            _cerrar_evento(cur, id_evento, "PROCESADO", {"id_producto": id_producto, "epc": epc, "resultado": "OK"})
            idp = self._crear_paquete(cur, id_recepcion, id_producto, epc, id_evento, codigo, "")
        return idp, epc

    def lectura_fallida(self, id_recepcion, folio, codigo, resultado, motivo, id_producto=None,
                        esperada=None, detectada=None, id_evento=None):
        """Problema de lectura en E3. Si el lector entregó un código, esa lectura pasa a RECHAZADO.
        Si no entregó nada, la incidencia apunta a la detección del IR que no tuvo lectura."""
        tipo, sev, accion = TIPOS_LECTURA[resultado]
        with self.conn, self.conn.cursor() as cur:
            if codigo is not None and id_evento:
                _cerrar_evento(cur, id_evento, "RECHAZADO", {"resultado": resultado})
            return _incidencia(cur, tipo, sev, motivo, accion, id_recepcion=id_recepcion, id_producto=id_producto,
                               id_evento=id_evento, esperada=esperada, detectada=detectada)

    def desvio(self, dispositivo, id_recepcion, folio, id_incidencia, id_paquete=None, id_producto=None):
        """Desviador a la zona de revisión. Si la caja ya es un paquete, pasa a cuarentena (CUA-01)."""
        with self.conn, self.conn.cursor() as cur:
            ide = _evento(cur, dispositivo, "DESVIO_A_REVISION", {"recepcion": folio, "incidencia": str(id_incidencia)})
            cur.execute("UPDATE incidencias SET estado = 'EN_REVISION' WHERE id_incidencia = %s", (id_incidencia,))
            if id_paquete:
                _estado_paquete(cur, id_paquete, "RETENIDO")
                self._mov(cur, id_producto, "CUARENTENA", self.cfg.UBIC_RECEPCION, self.cfg.UBIC_REVISION,
                          id_recepcion=id_recepcion, id_paquete=id_paquete, id_evento=ide,
                          obs="Desviada a revisión por el lector RFID")
            return ide

    # ------------------------------------------- revisión A (cajas sin paquete)
    def revision_a_aceptar(self, id_recepcion, folio, id_incidencia, codigo, id_producto, decision, obs):
        """El revisor confirma o captura el ID. Se crea el paquete y la caja regresa a la línea."""
        with self.conn, self.conn.cursor() as cur:
            epc = self._nuevo_epc(cur, id_producto)
            ide = _evento(cur, "LB-REV", "LECTURA_CODIGO_MANUAL", {"recepcion": folio, "codigo_barras": codigo,
                                                                   "id_producto": id_producto, "epc": epc, "resultado": "OK"})
            idp = self._crear_paquete(cur, id_recepcion, id_producto, epc, ide, codigo, "Aceptada en revisión A.")
            _revision(cur, id_incidencia, self.op, decision, obs)
            cur.execute("UPDATE incidencias SET id_paquete = %s, id_producto = %s WHERE id_incidencia = %s",
                        (idp, id_producto, id_incidencia))
            _auditoria(cur, "paquetes", epc, "ALTA_EN_REVISION", self.op, None,
                       {"epc": epc, "codigo_barras": codigo, "id_producto": id_producto, "decision": decision}, obs)
        return idp, epc

    def revision_a_captura_invalida(self, folio, id_incidencia, codigo, resultado, motivo, id_producto=None):
        tipo, sev, accion = TIPOS_LECTURA[resultado]
        with self.conn, self.conn.cursor() as cur:
            _evento(cur, "LB-REV", "LECTURA_CODIGO_MANUAL", {"recepcion": folio, "codigo_barras": codigo,
                                                            "resultado": resultado}, estado="RECHAZADO")
            cur.execute(
                """UPDATE incidencias SET tipo_incidencia = %s, severidad = %s, accion_recomendada = %s,
                       motivo = %s, id_producto = %s WHERE id_incidencia = %s""",
                (tipo, sev, accion, motivo, id_producto, id_incidencia))

    def revision_a_devolver(self, id_incidencia, obs):
        with self.conn, self.conn.cursor() as cur:
            _revision(cur, id_incidencia, self.op, "DEVOLVER", obs)
            _auditoria(cur, "incidencias", id_incidencia, "DEVOLVER_CAJA", self.op, None, {"decision": "DEVOLVER"}, obs)

    # --------------------------------------------- etapas 5 y 6: RFID
    def etiquetar_tag(self, folio, epc):
        """E5: la impresora-etiquetadora automática imprime, codifica y pega el tag de la caja."""
        with self.conn, self.conn.cursor() as cur:
            return _evento(cur, "IMP-RFID-E5", "ETIQUETADO_RFID", {"recepcion": folio}, epc=epc)

    def epc_confirmado(self, epc):
        with self.conn, self.conn.cursor() as cur:
            cur.execute("SELECT estado_validacion FROM paquetes WHERE epc_rfid = %s", (epc,))
            r = cur.fetchone()
            return bool(r) and r[0] in ("VALIDADO", "ALMACENADO", "VENDIDO")

    def lectura_rfid(self, folio, epc):
        """La antena fija de E6 lee un tag. Queda PENDIENTE hasta que el IR que está después
        de la antena confirme que pasó la caja."""
        with self.conn, self.conn.cursor() as cur:
            return _evento(cur, "RFID-E6", "LECTURA_RFID", {"recepcion": folio}, epc=epc, estado="PENDIENTE")

    def validar_rfid(self, id_recepcion, folio, id_lectura, id_ir, epc_leido, epc_esperado, resultado,
                     id_paquete, id_producto):
        """El IR de E6 confirmó la caja: se compara lo leído con el EPC esperado por posición.
        Devuelve el id de la incidencia, o None si todo coincide."""
        ok = resultado == "OK"
        with self.conn, self.conn.cursor() as cur:
            if id_lectura:
                _cerrar_evento(cur, id_lectura, "PROCESADO" if ok else "RECHAZADO",
                               {"epc_esperado": epc_esperado, "resultado": resultado})
            if ok:
                _estado_paquete(cur, id_paquete, "VALIDADO")
                return None
            if resultado == "SIN_LECTURA":
                motivo = (f"El IR que sigue a la antena detectó la caja y la antena no leyó ningún tag. "
                          f"Se esperaba {epc_esperado}.")
            elif resultado == "DUPLICADO":
                motivo = f"Se leyó {epc_leido}, que ya estaba confirmado. Se esperaba {epc_esperado}."
            else:
                motivo = f"Se leyó {epc_leido} y se esperaba {epc_esperado}."
            return _incidencia(cur, TIPOS_RFID[resultado], "MEDIA", motivo, "REETIQUETAR", id_recepcion=id_recepcion,
                               id_paquete=id_paquete, id_producto=id_producto, id_evento=id_lectura or id_ir)

    def almacenar(self, id_recepcion, id_paquete, id_producto):
        with self.conn, self.conn.cursor() as cur:
            _estado_paquete(cur, id_paquete, "ALMACENADO")
            self._mov(cur, id_producto, "ALMACENAMIENTO", self.cfg.UBIC_RECEPCION, self.cfg.UBIC_ALMACEN,
                      id_recepcion=id_recepcion, id_paquete=id_paquete)

    # ------------------------------------------- revisión B (paquetes RFID)
    def revision_b_reetiquetar(self, id_recepcion, folio, id_incidencia, id_paquete, id_producto, epc, codigo):
        with self.conn, self.conn.cursor() as cur:
            _evento(cur, "LB-REV", "LECTURA_CODIGO_MANUAL", {"recepcion": folio, "codigo_barras": codigo, "epc": epc,
                                                            "resultado": "OK"})
            ide = _evento(cur, "IMP-RFID-REV", "REIMPRESION_RFID", {"recepcion": folio}, epc=epc)
            _revision(cur, id_incidencia, self.op, "AJUSTAR", f"Se escaneó el ID {codigo} y se reimprimió el tag {epc}.")
            _estado_paquete(cur, id_paquete, "ALMACENADO")
            self._mov(cur, id_producto, "LIBERACION_CUARENTENA", self.cfg.UBIC_REVISION, self.cfg.UBIC_ALMACEN,
                      id_recepcion=id_recepcion, id_paquete=id_paquete, id_evento=ide, obs="Tag reimpreso en revisión")
            _auditoria(cur, "paquetes", epc, "REETIQUETAR", self.op, {"estado": "RETENIDO"}, {"estado": "ALMACENADO"},
                       "Revisión B")

    def revision_b_devolver(self, id_recepcion, id_incidencia, id_paquete, id_producto, epc):
        with self.conn, self.conn.cursor() as cur:
            _revision(cur, id_incidencia, self.op, "DEVOLVER", "Caja apartada para devolución al proveedor.")
            _estado_paquete(cur, id_paquete, "DEVUELTO")
            self._mov(cur, id_producto, "AJUSTE_SALIDA", self.cfg.UBIC_REVISION, None, id_recepcion=id_recepcion,
                      id_paquete=id_paquete, obs="Devolución al proveedor desde revisión")
            _auditoria(cur, "paquetes", epc, "DEVOLVER", self.op, {"estado": "RETENIDO"}, {"estado": "DEVUELTO"},
                       "Revisión B")

    # ------------------------------------------------------- cierre
    def cerrar_linea(self, id_recepcion, folio):
        """Compara lo esperado contra lo que llegó al almacén. Deja la recepción VALIDADA o CON_INCIDENCIAS."""
        diferencias = []
        with self.conn, self.conn.cursor() as cur:
            cur.execute(
                """SELECT d.id_producto, d.cantidad_esperada, COALESCE(a.n, 0)
                   FROM detalle_recepcion d
                   LEFT JOIN (SELECT dp.id_producto, COUNT(*) AS n FROM paquetes p JOIN detalle_paquete dp USING (id_paquete)
                              WHERE p.id_recepcion = %s AND p.estado_validacion IN ('ALMACENADO', 'VENDIDO')
                              GROUP BY dp.id_producto) a
                          USING (id_producto)
                   WHERE d.id_recepcion = %s ORDER BY d.id_producto""", (id_recepcion, id_recepcion))
            for prod, esperada, n in cur.fetchall():
                esperada = int(esperada)
                if n < esperada:
                    _incidencia(cur, "FALTANTE_PRODUCTO", "ALTA", f"Llegaron al almacén {n} de {esperada} cajas de {prod}.",
                                "RECLAMAR_FALTANTE", id_recepcion=id_recepcion, id_producto=prod, esperada=esperada, detectada=n)
                    diferencias.append((prod, esperada, n))
                elif n > esperada:
                    _incidencia(cur, "EXCEDENTE_RECIBIDO", "BAJA", f"Hay {n} cajas de {prod} en almacén y se esperaban {esperada}.",
                                "REGULARIZAR_CON_COMPRAS", id_recepcion=id_recepcion, id_producto=prod, esperada=esperada, detectada=n)
                    diferencias.append((prod, esperada, n))
            cur.execute("SELECT COUNT(*) FROM incidencias WHERE id_recepcion = %s AND estado IN ('PENDIENTE', 'EN_REVISION')",
                        (id_recepcion,))
            pendientes = cur.fetchone()[0]
            nuevo = "CON_INCIDENCIAS" if (diferencias or pendientes) else "VALIDADA"
            resumen = "Sin diferencias" if nuevo == "VALIDADA" else f"{len(diferencias)} diferencia(s) por producto"
            self._estado_recepcion(cur, id_recepcion, folio, nuevo, "Línea terminada. " + resumen)
        return nuevo, diferencias

    def cerrar_recepcion(self, id_recepcion, folio):
        with self.conn, self.conn.cursor() as cur:
            self._estado_recepcion(cur, id_recepcion, folio, "CERRADA", "Operador cierra la recepción")

    # ------------------------------------------------------- venta
    def paquetes_en_almacen(self):
        with self.conn, self.conn.cursor() as cur:
            cur.execute(
                """SELECT p.epc_rfid, dp.id_producto, pr.nombre FROM paquetes p
                   JOIN detalle_paquete dp USING (id_paquete) JOIN productos pr USING (id_producto)
                   WHERE p.estado_validacion = 'ALMACENADO'
                   ORDER BY p.fecha_registro, p.epc_rfid""")
            return cur.fetchall()

    def _datos_epc(self, cur, epc):
        cur.execute(
            """SELECT p.id_paquete, p.epc_rfid, p.estado_validacion, dp.id_producto, pr.nombre, pr.unidad_medida,
                      r.folio, r.documento_proveedor, pv.nombre AS proveedor, p.fecha_registro,
                      (SELECT o.folio FROM movimientos_inventario m JOIN ordenes_trabajo o USING (id_orden)
                       WHERE m.id_paquete = p.id_paquete AND m.tipo_movimiento = 'SALIDA'
                       ORDER BY m.fecha_movimiento DESC LIMIT 1) AS orden_venta
               FROM paquetes p JOIN detalle_paquete dp USING (id_paquete) JOIN productos pr USING (id_producto)
               JOIN recepciones r USING (id_recepcion) JOIN proveedores pv ON pv.id_proveedor = r.id_proveedor
               WHERE p.epc_rfid = %s""", (epc,))
        return cur.fetchone()

    def consultar_epc(self, epc):
        with self.conn, self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            _evento(cur, "RFID-VENTA", "LECTURA_RFID_VENTA", {"accion": "consulta"}, epc=epc)
            r = self._datos_epc(cur, epc)
            return dict(r) if r else None

    def registrar_venta(self, epc):
        with self.conn, self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            d = self._datos_epc(cur, epc)
            if not d:
                raise ValueError(f"El tag {epc} no está registrado en paquetes.")
            if d["estado_validacion"] == "VENDIDO":
                raise ValueError(f"La caja del tag {epc} ya se vendió" +
                                 (f" con la orden {d['orden_venta']}." if d["orden_venta"] else "."))
            if d["estado_validacion"] != "ALMACENADO":
                raise ValueError(f"La caja del tag {epc} no está disponible en el almacén "
                                 f"(estado {d['estado_validacion']}).")
            ide = _evento(cur, "RFID-VENTA", "LECTURA_RFID_VENTA", {"accion": "venta"}, epc=epc)
            cur.execute("SELECT to_char(NOW(), 'YYYYMMDD') AS hoy, (SELECT COUNT(*) FROM ordenes_trabajo) AS n")
            row = cur.fetchone()
            n = row["n"]
            while True:
                n += 1
                folio = f"OT-{row['hoy']}-{n:04d}"
                cur.execute("SELECT 1 FROM ordenes_trabajo WHERE folio = %s", (folio,))
                if cur.fetchone() is None:
                    break
            cur.execute(
                """INSERT INTO ordenes_trabajo (folio, tipo, departamento, solicitante_id, responsable_id, prioridad,
                       estado, fecha_cierre, observaciones)
                   VALUES (%s, 'SURTIDO', 'Ventas', 'mostrador', %s, 'MEDIA', 'COMPLETADA', NOW(), %s) RETURNING id_orden""",
                (folio, self.op, f"Venta en mostrador del tag {epc}"))
            ido = cur.fetchone()["id_orden"]
            cur.execute(
                """INSERT INTO detalle_orden_trabajo (id_orden, id_producto, cantidad_solicitada, cantidad_reservada,
                       cantidad_entregada) VALUES (%s, %s, 1, 1, 1)""", (ido, d["id_producto"]))
            self._mov(cur, d["id_producto"], "SALIDA", self.cfg.UBIC_ALMACEN, None, id_paquete=d["id_paquete"],
                      id_evento=ide, id_orden=ido, obs=f"Venta del tag {epc}")
            _estado_paquete(cur, d["id_paquete"], "VENDIDO")
            _auditoria(cur, "paquetes", epc, "VENTA", self.op, {"estado": "ALMACENADO"},
                       {"estado": "VENDIDO", "orden": folio}, "Venta en mostrador")
            _auditoria(cur, "ordenes_trabajo", folio, "VENTA", self.op, None,
                       {"epc": epc, "id_producto": d["id_producto"]}, "Venta en mostrador")
        return folio

    # ------------------------------------------------------- consultas
    def tabla(self, nombre, limite=200):
        """Filas de una opción de la pestaña Base de datos (las más recientes primero)."""
        _tabla, sql = VISTAS_BD[nombre]
        with self.conn, self.conn.cursor() as cur:
            cur.execute(sql + " LIMIT %s", (limite,))
            cols = [d[0] for d in cur.description]
            return cols, cur.fetchall()

    def contar(self, nombre):
        tabla = VISTAS_BD[nombre][0] if nombre in VISTAS_BD else nombre
        if tabla not in TABLAS_REQUERIDAS:
            raise ValueError(nombre)
        with self.conn, self.conn.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) FROM {tabla}")
            return cur.fetchone()[0]

    def conteos(self):
        """Filas de cada opción de la pestaña Base de datos, en una sola consulta."""
        sql = "SELECT " + ", ".join(f"(SELECT COUNT(*) FROM {t})" for t, _ in VISTAS_BD.values())
        with self.conn, self.conn.cursor() as cur:
            cur.execute(sql)
            return dict(zip(VISTAS_BD, cur.fetchone()))

    def existencias(self):
        with self.conn, self.conn.cursor() as cur:
            cur.execute(
                """SELECT id_producto, producto, id_ubicacion, cantidad_fisica, cantidad_reservada, cantidad_disponible
                   FROM vw_existencias_disponibles ORDER BY id_producto, id_ubicacion""")
            return cur.fetchall()

    def conciliacion(self, id_recepcion):
        with self.conn, self.conn.cursor() as cur:
            cur.execute(
                """WITH paq AS (SELECT dp.id_producto, p.estado_validacion FROM paquetes p
                                JOIN detalle_paquete dp USING (id_paquete) WHERE p.id_recepcion = %s),
                        prods AS (SELECT id_producto FROM detalle_recepcion WHERE id_recepcion = %s
                                  UNION SELECT id_producto FROM paq)
                   SELECT pr.id_producto, pr.nombre, COALESCE(d.cantidad_esperada, 0),
                          COUNT(paq.id_producto) FILTER (WHERE paq.estado_validacion <> 'DEVUELTO'),
                          COUNT(paq.id_producto) FILTER (WHERE paq.estado_validacion IN ('ALMACENADO', 'VENDIDO')),
                          COUNT(paq.id_producto) FILTER (WHERE paq.estado_validacion = 'RETENIDO'),
                          COUNT(paq.id_producto) FILTER (WHERE paq.estado_validacion = 'DEVUELTO'),
                          COUNT(paq.id_producto) FILTER (WHERE paq.estado_validacion = 'VENDIDO')
                   FROM prods JOIN productos pr USING (id_producto)
                   LEFT JOIN detalle_recepcion d ON d.id_recepcion = %s AND d.id_producto = pr.id_producto
                   LEFT JOIN paq ON paq.id_producto = pr.id_producto
                   GROUP BY pr.id_producto, pr.nombre, d.cantidad_esperada
                   ORDER BY pr.id_producto""", (id_recepcion, id_recepcion, id_recepcion))
            return cur.fetchall()
