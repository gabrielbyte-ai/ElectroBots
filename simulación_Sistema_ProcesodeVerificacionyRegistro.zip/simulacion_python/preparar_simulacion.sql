-- =====================================================================
-- Preparación para la simulación. main.py lo ejecuta solo al iniciar.
-- Es seguro correrlo varias veces: no borra datos. Solo agrega lo que
-- falta y pone al día lo que dejaron versiones anteriores de la simulación.
-- Si tu base se creó con papeleria_postgresql_v2.sql, ya tiene todo esto.
-- =====================================================================

-- 1) Numeración del proveedor: los 2 dígitos con los que el ID de cada
--    caja indica su contenido. Solo se llena si está vacía:
--    P-001 -> 01, P-002 -> 02 ... P-016 -> 16
UPDATE proveedor_productos
SET codigo_proveedor = RIGHT(id_producto, 2)
WHERE id_proveedor = 'PROV-001'
  AND codigo_proveedor IS NULL
  AND id_producto ~ '^P-[0-9]{3}$';

-- 2) Dispositivos IoT de la línea, para que eventos_iot pueda referenciarlos.
INSERT INTO dispositivos_iot (id_dispositivo, tipo, ubicacion) VALUES
  ('IR-E1',        'SENSOR_IR',            'E1 Banda de recepción, conteo'),
  ('IR-E3',        'SENSOR_IR',            'E3 Línea, después del lector de barras'),
  ('LB-E3',        'LECTOR_CODIGO_BARRAS', 'E3 Línea principal'),
  ('DESV-D1',      'DESVIADOR',            'E4 Línea principal'),
  ('IMP-RFID-E5',  'ETIQUETADORA_RFID',    'E5 Línea principal, imprime, codifica y pega el tag'),
  ('IR-E6',        'SENSOR_IR',            'E6 Línea, después del lector RFID'),
  ('RFID-E6',      'LECTOR_RFID_FIJO',     'E6 Línea principal'),
  ('DESV-D2',      'DESVIADOR',            'E6 Línea principal'),
  ('LB-REV',       'LECTOR_CODIGO_MANO',   'Zona de revisión humana'),
  ('IMP-RFID-REV', 'IMPRESORA_RFID',       'Zona de revisión humana'),
  ('RFID-VENTA',   'LECTOR_RFID_MANO',     'Punto de venta')
ON CONFLICT (id_dispositivo) DO NOTHING;

-- 3) Los IR de E3 y E6 van después de su lector. Corrige la descripción que
--    dejó la primera versión de este archivo (solo si sigue igual).
UPDATE dispositivos_iot SET ubicacion = 'E3 Línea, después del lector de barras'
WHERE id_dispositivo = 'IR-E3' AND ubicacion = 'E3 Línea, antes del lector de barras';
UPDATE dispositivos_iot SET ubicacion = 'E6 Línea, después del lector RFID'
WHERE id_dispositivo = 'IR-E6' AND ubicacion = 'E6 Línea, antes del lector RFID';

-- 4) E5 ya no es una impresora con una persona que pega el tag: es una sola
--    impresora-etiquetadora automática. Corrige el registro anterior.
UPDATE dispositivos_iot
SET tipo = 'ETIQUETADORA_RFID', ubicacion = 'E5 Línea principal, imprime, codifica y pega el tag'
WHERE id_dispositivo = 'IMP-RFID-E5' AND tipo = 'IMPRESORA_RFID';

-- 5) Estado VENDIDO en paquetes: la caja salió del almacén por una venta.
--    Si el CHECK de estado_validacion todavía no lo acepta, se reemplaza por
--    uno igual que además incluye VENDIDO.
DO $$
DECLARE
    r RECORD;
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conrelid = 'paquetes'::regclass AND contype = 'c'
          AND pg_get_constraintdef(oid) LIKE '%estado_validacion%'
          AND pg_get_constraintdef(oid) LIKE '%VENDIDO%') THEN
        FOR r IN
            SELECT conname FROM pg_constraint
            WHERE conrelid = 'paquetes'::regclass AND contype = 'c'
              AND pg_get_constraintdef(oid) LIKE '%estado_validacion%'
        LOOP
            EXECUTE format('ALTER TABLE paquetes DROP CONSTRAINT %I', r.conname);
        END LOOP;
        ALTER TABLE paquetes ADD CONSTRAINT paquetes_estado_validacion_check
            CHECK (estado_validacion IN ('PENDIENTE', 'VALIDADO', 'RETENIDO', 'ALMACENADO', 'DEVUELTO', 'VENDIDO'));
    END IF;
END $$;

-- 6) Las cajas que se vendieron con la versión anterior de la simulación
--    quedaron ALMACENADO aunque tienen su SALIDA. Pasan a VENDIDO y queda
--    el cambio en auditoria.
WITH vendidos AS (
    UPDATE paquetes p SET estado_validacion = 'VENDIDO'
    WHERE p.estado_validacion = 'ALMACENADO'
      AND EXISTS (SELECT 1 FROM movimientos_inventario m
                  WHERE m.id_paquete = p.id_paquete AND m.tipo_movimiento = 'SALIDA')
    RETURNING p.epc_rfid
)
INSERT INTO auditoria (entidad, id_registro, accion, usuario_id, valor_anterior, valor_nuevo, motivo)
SELECT 'paquetes', epc_rfid, 'VENTA', 'preparar_simulacion', '{"estado": "ALMACENADO"}', '{"estado": "VENDIDO"}',
       'Vendida antes de que existiera el estado VENDIDO'
FROM vendidos;
