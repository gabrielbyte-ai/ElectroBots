"""Ventana principal: barra de control, panel de la orden, planta animada y pestañas."""
import time
import tkinter as tk
import traceback
from tkinter import messagebox, ttk

import psycopg2

from estilo import COL, aplicar_estilo
from motor import N, P, Motor
from paneles import PanelOrden, TabBD, TabBitacora, TabConciliacion, TabTareas, TabVenta
from planta import H as PLANTA_H, W as PLANTA_W, Planta

VELOCIDADES = [1400, 1000, 750, 550, 400, 280, 180, 110]   # milisegundos por tramo de banda

FASES = {
    "sin_recepcion": ("Sin recepción en curso", COL["texto2"]),
    "descarga": ("E1 · Descarga y conteo IR", COL["acento"]),
    "espera_aprobacion": ("E1 · Esperando tu aprobación", COL["aviso"]),
    "linea": ("Línea en marcha", COL["ok"]),
    "fin": ("Terminada", COL["acento"]),
    "cerrada": ("Cerrada", COL["ok"]),
    "cancelada": ("Rechazada (CANCELADA)", COL["error"]),
}

LUGARES = {
    "camion": "en el camión", "banda_rec": "en la banda de recepción", "espera": "en la zona de espera",
    "linea": "en la línea principal", "revA": "en revisión A", "reingreso": "esperando reingreso a la línea",
    "revB": "en revisión B", "almacen": "en el almacén", "devuelta": "devuelta al proveedor", "vendida": "vendida",
}

ESTACIONES = {0: "E2 carga manual", P["CAM"]: "E3 lector de barras", P["IR3"]: "IR de E3, confirma la lectura",
              P["D1"]: "E4 desviador D1", P["REINS"]: "punto de reingreso",
              P["ETQ"]: "E5 impresora-etiquetadora RFID automática", P["RDR"]: "E6 lector RFID",
              P["IR6"]: "IR de E6, confirma la lectura", P["D2"]: "E6 desviador D2"}


class App:
    def __init__(self, root, bd, cfg):
        self.root, self.bd, self.cfg = root, bd, cfg
        self.f = aplicar_estilo(root)
        self.motor = Motor(bd, cfg)
        self.corriendo = False
        self.sel = None
        self.sucio = True
        self.redibujar = True
        self.espera_idle = 0.0
        self.ultimo_ui = self.ultimo_bd = 0.0
        self.error_mostrado = False
        self.var_verdad = tk.BooleanVar(value=False)
        self.vel_idx = min(range(len(VELOCIDADES)), key=lambda i: abs(VELOCIDADES[i] - cfg.VELOCIDAD_MS))
        self._ventana()
        self._barra()
        self._cuerpo()
        self.root.bind("<space>", self._tecla_espacio)
        self.root.bind("<Right>", self._tecla_paso)
        self.root.protocol("WM_DELETE_WINDOW", self.salir)
        self.motor.log("Inicio", f"Conectado a {cfg.BD['dbname']} en {cfg.BD['host']}:{cfg.BD['port']}. "
                                 f"Proveedor {self.motor.id_proveedor} con {len(self.motor.catalogo)} productos.", "ok")
        self._actualizar_barra()
        self._t_prev = time.perf_counter()
        self.root.after(60, self._tick)

    # ------------------------------------------------------------ ventana
    def _ventana(self):
        r = self.root
        r.title(f"Línea de Recepción IoT · {self.cfg.BD['dbname']}")
        k = max(1.0, r.winfo_fpixels("1i") / 96.0)
        sw, sh = r.winfo_screenwidth(), r.winfo_screenheight()
        w, h = min(int(1440 * k), sw - 40), min(int(920 * k), sh - 80)
        r.geometry(f"{w}x{h}+{max(0, (sw - w) // 2)}+{max(0, (sh - h) // 3)}")
        r.minsize(min(1100, sw - 40), min(660, sh - 80))

    def _barra(self):
        b = ttk.Frame(self.root, style="Panel.TFrame", padding=(10, 6))
        b.pack(fill="x")
        self.lbl_titulo = tk.Label(b, text="Línea de Recepción IoT", bg=COL["panel"], fg=COL["texto"],
                                   font=self.f["titulo"])
        self.lbl_titulo.pack(side="left", padx=(0, 14))
        b.bind("<Configure>", self._ajustar_barra, add="+")
        self.btn_run = ttk.Button(b, text="Ejecutar", style="Acento.TButton", width=11, command=self.alternar)
        self.btn_run.pack(side="left")
        self.btn_paso = ttk.Button(b, text="Un paso", command=self.un_paso)
        self.btn_paso.pack(side="left", padx=6)
        ttk.Label(b, text="Velocidad", style="Panel.TLabel").pack(side="left", padx=(10, 4))
        self.escala = ttk.Scale(b, from_=0, to=len(VELOCIDADES) - 1, orient="horizontal", length=120,
                                command=self._vel)
        self.escala.set(self.vel_idx)
        self.escala.pack(side="left", padx=(0, 4))
        # Lo de la derecha se empaca antes que la fase para que nunca se recorte
        ttk.Checkbutton(b, text="Ver verdad física", variable=self.var_verdad, style="Panel.TCheckbutton",
                        command=self._marcar_redibujo).pack(side="right", padx=(12, 0))
        ttk.Separator(b, orient="vertical").pack(side="left", fill="y", padx=8)
        self.lbl_fase = tk.Label(b, text="", bg=COL["panel"], fg=COL["texto"], font=self.f["negrita"], anchor="w")
        self.lbl_fase.pack(side="left", fill="x", expand=True)

        pie = tk.Frame(self.root, bg=COL["panel2"])
        pie.pack(side="bottom", fill="x")
        cfg = self.cfg.BD
        self.lbl_con = tk.Label(pie, text=f"● Conectado a {cfg['dbname']} en {cfg['host']}:{cfg['port']} "
                                          f"(usuario {cfg['user']}) · operador {self.cfg.OPERADOR}",
                                bg=COL["panel2"], fg=COL["ok"], font=self.f["chica"], padx=10, pady=3)
        self.lbl_con.pack(side="left")
        tk.Label(pie, text="Espacio: ejecutar o pausar · Flecha derecha: un paso · Clic en una caja: ver sus datos",
                 bg=COL["panel2"], fg=COL["texto2"], font=self.f["chica"], padx=10).pack(side="right")

    def _ajustar_barra(self, e):
        """En pantallas angostas el título se oculta para que quepa la fase."""
        visible = bool(self.lbl_titulo.winfo_manager())
        if e.width < 1380 and visible:
            self.lbl_titulo.pack_forget()
        elif e.width >= 1380 and not visible:
            self.lbl_titulo.pack(side="left", padx=(0, 14), before=self.btn_run)

    def _cuerpo(self):
        cuerpo = ttk.PanedWindow(self.root, orient="horizontal")
        cuerpo.pack(fill="both", expand=True, padx=8, pady=(6, 6))
        izq = ttk.Frame(cuerpo, style="Panel.TFrame")
        self.panel = PanelOrden(izq, self)
        self.panel.pack(fill="both", expand=True)
        der = ttk.PanedWindow(cuerpo, orient="vertical")
        cuerpo.add(izq, weight=0)
        cuerpo.add(der, weight=1)

        arriba = ttk.Frame(der, style="Panel.TFrame")
        self.lbl_insp = tk.Label(arriba, text="", bg=COL["panel2"], fg=COL["texto"], anchor="nw", justify="left",
                                 font=self.f["chica"], padx=10, pady=4, wraplength=1000, height=2)
        self.lbl_insp.pack(side="bottom", fill="x")
        self.cv = tk.Canvas(arriba, bg=COL["fondo"], highlightthickness=0, height=380, width=900)
        self.cv.pack(side="top", fill="both", expand=True)
        self.lbl_insp.bind("<Configure>", lambda e: self.lbl_insp.configure(wraplength=max(300, e.width - 20)))
        der.add(arriba, weight=3)

        self.nb = ttk.Notebook(der)
        der.add(self.nb, weight=2)
        self.tab_tareas = TabTareas(self.nb, self)
        self.tab_conc = TabConciliacion(self.nb, self)
        self.tab_bd = TabBD(self.nb, self)
        self.tab_venta = TabVenta(self.nb, self)
        self.tab_bit = TabBitacora(self.nb, self)
        for tab, texto in ((self.tab_tareas, "Tareas"), (self.tab_conc, "Conciliación"),
                           (self.tab_bd, "Base de datos"), (self.tab_venta, "Venta de producto"),
                           (self.tab_bit, "Bitácora")):
            self.nb.add(tab, text=texto)
        self._titulo_tareas = "Tareas"

        self.planta = Planta(self.cv, self.f)
        self.cv.bind("<Button-1>", self._clic)
        self.cv.bind("<Configure>", lambda e: self._marcar_redibujo())
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self._refrescar_tab(forzar=True))
        self._sash_listo = False
        der.bind("<Configure>", lambda e: self._sash(der), add="+")

    def _sash(self, der):
        """La primera vez, deja a la planta la altura justa para su ancho y el resto a las pestañas."""
        if self._sash_listo:
            return
        try:
            ancho, alto = der.winfo_width(), der.winfo_height()
            if ancho < 400 or alto < 400:
                return
            escala = max(0.55, min(2.0, ancho / PLANTA_W))
            deseado = int(PLANTA_H * escala) + 12 + self.lbl_insp.winfo_reqheight()
            der.sashpos(0, max(220, min(deseado, alto - 230)))
            self._sash_listo = True
        except tk.TclError:
            pass

    # ------------------------------------------------------------ control
    def vel(self):
        return VELOCIDADES[self.vel_idx]

    def _vel(self, valor):
        self.vel_idx = int(round(float(valor)))

    def puede_correr(self):
        return self.motor.fase in ("descarga", "espera_aprobacion", "linea")

    def alternar(self):
        if not self.puede_correr():
            messagebox.showinfo("Sin recepción", "Arma una orden en el panel izquierdo y pulsa «Iniciar recepción».")
            return
        self.corriendo = not self.corriendo
        self._actualizar_barra()

    def un_paso(self):
        if not self.puede_correr():
            return
        self.corriendo = False
        if self.motor.fase == "espera_aprobacion":
            self.nb.select(self.tab_tareas)
        self._paso(min(self.vel(), 350))
        self._actualizar_barra()

    def _tecla_espacio(self, e):
        if not self._escribiendo():
            self.alternar()
            return "break"

    def _tecla_paso(self, e):
        if not self._escribiendo():
            self.un_paso()
            return "break"

    def _escribiendo(self):
        w = self.root.focus_get()
        return isinstance(w, (tk.Entry, ttk.Entry, tk.Text, tk.Spinbox))

    def _marcar_redibujo(self):
        self.redibujar = True

    # ---------------------------------------------------- llamadas al motor
    def seguro(self, fn, *args):
        """Ejecuta una operación del motor. Si la base la rechaza, avisa y pausa."""
        try:
            return True, fn(*args)
        except (ValueError, RuntimeError) as e:
            messagebox.showwarning("Revisa los datos", str(e), parent=self.root)
        except psycopg2.Error as e:
            self.corriendo = False
            detalle = (getattr(e, "pgerror", None) or str(e)).strip()
            if self.bd.conn.closed:
                self.lbl_con.configure(text="● Sin conexión con la base de datos", fg=COL["error"])
                detalle += "\n\nSe perdió la conexión. Revisa que PostgreSQL siga encendido y vuelve a abrir la simulación."
            messagebox.showerror("Error de la base de datos",
                                 "La base rechazó la operación. Ese paso no se guardó.\n\n" + detalle, parent=self.root)
            self._actualizar_barra()
        return False, None

    def _paso(self, dur):
        fase = self.motor.fase
        antes = self.planta.posiciones()
        ok, movio = self.seguro(self.motor.paso)
        if not ok:
            return
        if movio:
            self.planta.animar(antes, self.motor, dur, rec=(fase == "descarga"), lin=(fase == "linea"))
        else:
            self.planta.animar(antes, self.motor, 1)
            self.espera_idle = 300.0
            self.redibujar = True
        self._tras_cambio(fase)

    def accion(self, fn, *args, animar=True):
        """Decisión de una persona (aprobar, revisar, cerrar, vender…)."""
        fase = self.motor.fase
        antes = self.planta.posiciones()
        ok, res = self.seguro(fn, *args)
        if animar:
            self.planta.animar(antes, self.motor, 380)
        self.redibujar = True
        self._tras_cambio(fase)
        return ok, res

    def _tras_cambio(self, fase_antes):
        self.sucio = True
        m = self.motor
        if m.fase != fase_antes:
            if m.fase in ("espera_aprobacion", "fin"):
                self.nb.select(self.tab_tareas)
            if not self.puede_correr():
                self.corriendo = False
            self._actualizar_barra()
            self.panel.actualizar()

    def iniciar(self, documento, lineas, faltan, excedentes, danados, cruces):
        m = self.motor
        if m.fase == "fin":
            if not messagebox.askyesno("Recepción sin cerrar", f"La recepción {m.folio} ya terminó pero no se ha "
                                                               "cerrado. ¿La cierro y empiezo la nueva?"):
                return
            ok, _ = self.accion(m.cerrar_recepcion, animar=False)
            if not ok:
                return
        fase = m.fase
        antes = self.planta.posiciones()
        ok, _ = self.seguro(m.nueva_recepcion, documento, lineas, faltan, excedentes, danados, cruces)
        if not ok:
            return
        self.sel = None
        self.tab_tareas.capturas.clear()
        self.tab_tareas.mensajes.clear()
        self.planta.animar(antes, m, 1)
        self.panel.siguiente_documento()
        self.corriendo = True
        self._tras_cambio(fase)
        self.nb.select(self.tab_tareas)

    def cambiar_proveedor(self, id_proveedor):
        ok, _ = self.seguro(self.motor.cargar_catalogo, id_proveedor)
        self.planta.colores.clear()
        return ok

    def salir(self):
        m = self.motor
        if m.en_curso() and not messagebox.askyesno(
                "Salir", f"La recepción {m.folio} sigue en curso y quedará así en la base. ¿Salir de todos modos?"):
            return
        self.bd.cerrar()
        self.root.destroy()

    # --------------------------------------------------------- ciclo de UI
    def _tick(self):
        ahora = time.perf_counter()
        dt = (ahora - self._t_prev) * 1000.0
        self._t_prev = ahora
        try:
            animando = self.planta.avanzar(dt)
            if self.corriendo and not animando:
                if self.espera_idle > 0:
                    self.espera_idle -= dt
                else:
                    self._paso(self.vel())
                    animando = True
            if animando or self.redibujar:
                self.redibujar = False
                self.planta.dibujar(self.motor, self.var_verdad.get(), self.sel)
            self._periodico(ahora)
        except Exception:
            traceback.print_exc()
            self.corriendo = False
            if not self.error_mostrado:
                self.error_mostrado = True
                messagebox.showerror("Error inesperado", traceback.format_exc(limit=4), parent=self.root)
        finally:
            self.root.after(30, self._tick)

    def _periodico(self, ahora):
        if ahora - self.ultimo_ui < 0.25:
            return
        self.ultimo_ui = ahora
        self._actualizar_barra()
        self.tab_tareas.refrescar()
        n = self.tab_tareas.pendientes()
        titulo = f"Tareas ({n})" if n else "Tareas"
        if titulo != self._titulo_tareas:
            self.nb.tab(self.tab_tareas, text=titulo)
            self._titulo_tareas = titulo
        self.tab_bit.refrescar()
        self._inspector()
        if self.sucio and ahora - self.ultimo_bd >= 0.8:
            self._refrescar_tab()

    def _refrescar_tab(self, forzar=False):
        try:
            actual = self.nb.nametowidget(self.nb.select())
        except (KeyError, tk.TclError):
            return
        self.ultimo_bd = time.perf_counter()
        self.sucio = False
        try:
            if actual is self.tab_tareas:
                actual.refrescar(forzar=forzar)
            elif actual is self.tab_bit:
                actual.refrescar()
                if forzar:
                    self.root.after(60, actual.al_final)
            elif actual is self.tab_bd:
                if forzar or actual.auto():
                    actual.refrescar()
            elif actual is self.tab_venta:
                if forzar:
                    actual.refrescar()
            else:
                actual.refrescar()
        except psycopg2.Error as e:
            self.lbl_insp.configure(text=f"No se pudo leer la base: {(getattr(e, 'pgerror', None) or str(e)).strip()}",
                                    fg=COL["error"])

    def _actualizar_barra(self):
        m = self.motor
        texto, color = FASES.get(m.fase, (m.fase, COL["texto"]))
        if m.fase == "fin" and m.resultado_cierre:
            estado = m.resultado_cierre[0]
            texto += f" · {estado}"
            color = COL["ok"] if estado == "VALIDADA" else COL["aviso"]
        elif m.fase == "linea" and (m.rev_a or m.rev_b) and not any(m.linea) and not m.espera and not m.reingreso:
            texto, color = "Faltan decisiones en revisión", COL["aviso"]
        if m.folio and m.fase != "sin_recepcion":
            texto = f"{m.folio} · {texto}"
        if self.lbl_fase.cget("text") != texto:
            self.lbl_fase.configure(text=texto, fg=color)
        corre = self.corriendo and self.puede_correr()
        self.btn_run.configure(text="Pausar" if corre else "Ejecutar")
        self.btn_run.state(["!disabled"] if self.puede_correr() else ["disabled"])
        self.btn_paso.state(["!disabled"] if self.puede_correr() else ["disabled"])

    # ------------------------------------------------------- inspector
    def _clic(self, e):
        self.sel = self.planta.caja_en(e.x, e.y)
        self.redibujar = True
        self._inspector()

    def _inspector(self):
        m = self.motor
        c = m.cajas.get(self.sel) if self.sel else None
        if c is None or c.loc == "vendida":
            ultimo = m.bitacora[-1] if m.bitacora else None
            texto = "Haz clic en una caja para ver qué sabe la base de ella."
            if ultimo:
                texto += f"   Último evento: [{ultimo[1]}] {ultimo[2]}"
        else:
            lugar = LUGARES.get(c.loc, c.loc)
            if c.loc == "linea" and c.pid in m.linea:
                i = m.linea.index(c.pid)
                lugar += f", tramo {i + 1} de {N}" + (f" ({ESTACIONES[i]})" if i in ESTACIONES else "")
            if c.loc == "revB":
                lugar += f" ({self.cfg.UBIC_REVISION})"
            if c.loc == "almacen":
                lugar += f" ({self.cfg.UBIC_ALMACEN})"
            partes = [f"Caja #{c.pid} {lugar}",
                      f"etiqueta del proveedor: ID {c.codigo_barras}" + (" con código de barras dañado" if not c.legible else "")]
            if c.epc:
                partes.append(f"en la base: paquete {c.epc} = {c.id_producto_sis} {m.nombre(c.id_producto_sis)}")
            else:
                partes.append("en la base: todavía sin paquete")
            partes.append("con tag RFID" if c.tag else "sin tag RFID")
            if c.desvio:
                partes.append("incidencia: " + c.desvio["motivo"].replace("_", " ").lower())
            if self.var_verdad.get():
                partes.append(f"VERDAD FÍSICA: contiene {c.id_producto} {c.nombre}")
                if c.tag and c.tag != c.epc:
                    partes.append(f"el tag pegado es {c.tag}, de otra caja")
                if c.verdad:
                    partes.append("; ".join(c.verdad))
            texto = " · ".join(partes)
        if self.lbl_insp.cget("text") != texto:
            self.lbl_insp.configure(text=texto, fg=COL["texto"])
