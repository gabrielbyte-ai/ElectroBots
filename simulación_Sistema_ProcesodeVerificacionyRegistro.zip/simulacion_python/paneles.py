"""Panel de la orden de compra (izquierda) y pestañas de la parte inferior."""
import json
import tkinter as tk
import tkinter.font as tkfont
import uuid
from datetime import date, datetime
from decimal import Decimal
from tkinter import messagebox, ttk

from bd import VISTAS_BD
from estilo import COL, Desplazable, etiquetar_arbol
from motor import MOTIVOS


def fmt(v):
    """Valor de la base como texto para las tablas."""
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, Decimal):
        t = format(v, "f")
        return t.rstrip("0").rstrip(".") if "." in t else t
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False)
    if isinstance(v, uuid.UUID):
        return str(v)
    return str(v)


def entero(var, minimo=0, maximo=999):
    try:
        n = int(str(var.get()).strip())
    except (ValueError, tk.TclError):
        n = minimo
    return max(minimo, min(maximo, n))


def arbol_con_barras(padre, columnas, encabezados, anchos, alto=8):
    marco = ttk.Frame(padre, style="Panel.TFrame")
    arbol = ttk.Treeview(marco, columns=columnas, show="headings", height=alto)
    for c, e, a in zip(columnas, encabezados, anchos):
        arbol.heading(c, text=e, anchor="w")
        arbol.column(c, width=a, minwidth=40, stretch=a >= 200, anchor="w")
    by = ttk.Scrollbar(marco, orient="vertical", command=arbol.yview)
    bx = ttk.Scrollbar(marco, orient="horizontal", command=arbol.xview)
    arbol.configure(yscrollcommand=by.set, xscrollcommand=bx.set)
    arbol.grid(row=0, column=0, sticky="nsew")
    by.grid(row=0, column=1, sticky="ns")
    bx.grid(row=1, column=0, sticky="ew")
    marco.rowconfigure(0, weight=1)
    marco.columnconfigure(0, weight=1)
    etiquetar_arbol(arbol)
    return marco, arbol


# =====================================================================
# Panel izquierdo: orden de compra, fallas y entrega real
# =====================================================================
class PanelOrden(ttk.Frame):
    def __init__(self, padre, app):
        super().__init__(padre, style="Panel.TFrame", padding=(12, 10))
        self.app = app
        self.filas = []

        ttk.Label(self, text="Orden de compra", style="Seccion.TLabel").pack(anchor="w")
        f1 = ttk.Frame(self, style="Panel.TFrame")
        f1.pack(fill="x", pady=(6, 2))
        ttk.Label(f1, text="Proveedor", style="Panel.TLabel", width=10).pack(side="left")
        self.cb_prov = ttk.Combobox(f1, state="readonly", width=22)
        self.cb_prov.pack(side="left", fill="x", expand=True)
        self.cb_prov.bind("<<ComboboxSelected>>", self._cambiar_proveedor)
        f2 = ttk.Frame(self, style="Panel.TFrame")
        f2.pack(fill="x", pady=2)
        ttk.Label(f2, text="Documento", style="Panel.TLabel", width=10).pack(side="left")
        self.var_doc = tk.StringVar()
        ttk.Entry(f2, textvariable=self.var_doc).pack(side="left", fill="x", expand=True)

        ttk.Label(self, text="Numeración de producto y número de cajas", style="Sub.TLabel").pack(anchor="w", pady=(8, 2))
        self.lista = Desplazable(self, alto=196)
        self.lista.pack(fill="x")
        f3 = ttk.Frame(self, style="Panel.TFrame")
        f3.pack(fill="x", pady=(4, 0))
        ttk.Button(f3, text="+ Agregar producto", command=self.agregar).pack(side="left")
        self.lbl_total = ttk.Label(f3, text="", style="Sub.TLabel")
        self.lbl_total.pack(side="right")

        ttk.Separator(self).pack(fill="x", pady=10)
        ttk.Label(self, text="Fallas a simular", style="Seccion.TLabel").pack(anchor="w")
        self.var_danados = self._numero("Código de barras dañado", "cajas", 1)
        self.var_cruces = self._numero("Tag RFID pegado en la caja equivocada", "veces", 1)

        ttk.Separator(self).pack(fill="x", pady=10)
        ttk.Label(self, text="Lo que realmente entrega el proveedor", style="Seccion.TLabel").pack(anchor="w")
        self.var_faltan = self._numero("Cajas que faltan", "cajas", 1)
        self.var_excedentes = self._numero("Cajas excedentes", "cajas", 1)

        self.lbl_camion = ttk.Label(self, text="", style="Sub.TLabel", wraplength=290, justify="left")
        self.lbl_camion.pack(anchor="w", pady=(10, 6))
        self.btn_iniciar = ttk.Button(self, text="Iniciar recepción", style="Acento.TButton", command=self.iniciar)
        self.btn_iniciar.pack(fill="x")
        ttk.Label(self, text="Las fallas y la entrega real solo las conoce la simulación. La base recibe "
                             "únicamente lo que leen los sensores y lo que deciden las personas.",
                  style="Sub.TLabel", wraplength=290, justify="left").pack(anchor="w", pady=(10, 0))

        for v in (self.var_danados, self.var_cruces, self.var_faltan, self.var_excedentes):
            v.trace_add("write", lambda *_: self._resumen())
        self.cargar_proveedores()
        for prod, cajas in app.cfg.ORDEN_EJEMPLO:
            if prod in app.motor.catalogo:
                self.agregar(prod, cajas)
        if not self.filas:
            self.agregar()
        self.siguiente_documento()
        self._resumen()

    def _numero(self, texto, unidad, valor):
        f = ttk.Frame(self, style="Panel.TFrame")
        f.pack(fill="x", pady=3)
        var = tk.StringVar(value=str(valor))
        ttk.Label(f, text=texto, style="Panel.TLabel", wraplength=190, justify="left").pack(side="left")
        ttk.Label(f, text=unidad, style="Sub.TLabel", width=6).pack(side="right")
        ttk.Spinbox(f, from_=0, to=99, width=4, textvariable=var).pack(side="right", padx=(6, 4))
        return var

    # ---------------------------------------------------------- proveedor
    def cargar_proveedores(self):
        provs = self.app.bd.proveedores()
        self._provs = {f"{i} · {n}": i for i, n in provs}
        self.cb_prov["values"] = list(self._provs)
        for etiqueta, i in self._provs.items():
            if i == self.app.motor.id_proveedor:
                self.cb_prov.set(etiqueta)

    def _cambiar_proveedor(self, _e=None):
        nuevo = self._provs.get(self.cb_prov.get())
        if not nuevo or nuevo == self.app.motor.id_proveedor:
            return
        if self.app.motor.en_curso():
            messagebox.showinfo("Recepción en curso", "Cambia de proveedor cuando termine la recepción actual.")
            self.cargar_proveedores()
            return
        if self.app.cambiar_proveedor(nuevo):
            for fila in list(self.filas):
                self._quitar(fila)
            self.agregar()

    def productos(self):
        return [f"{p} · {c['nombre']} ({c['codigo_proveedor'] or 'sin numeración'})"
                for p, c in sorted(self.app.motor.catalogo.items())]

    # ------------------------------------------------------------ filas
    def agregar(self, prod=None, cajas=4):
        f = ttk.Frame(self.lista.interior, style="Panel.TFrame")
        f.pack(fill="x", pady=2)
        valores = self.productos()
        cb = ttk.Combobox(f, state="readonly", values=valores, width=22)
        if prod:
            for v in valores:
                if v.startswith(prod + " "):
                    cb.set(v)
        elif valores:
            usados = {self._id(x[1].get()) for x in self.filas}
            libres = [v for v in valores if self._id(v) not in usados]
            cb.set((libres or valores)[0])
        cb.pack(side="left", fill="x", expand=True)
        var = tk.StringVar(value=str(cajas))
        ttk.Spinbox(f, from_=1, to=99, width=4, textvariable=var).pack(side="left", padx=4)
        fila = (f, cb, var)
        ttk.Button(f, text="×", width=2, command=lambda: self._quitar(fila)).pack(side="left")
        var.trace_add("write", lambda *_: self._resumen())
        cb.bind("<<ComboboxSelected>>", lambda e: self._resumen())
        self.filas.append(fila)
        self._resumen()

    def _quitar(self, fila):
        if fila in self.filas:
            self.filas.remove(fila)
            fila[0].destroy()
            self._resumen()

    @staticmethod
    def _id(texto):
        return texto.split(" · ")[0].strip() if texto else ""

    def lineas(self):
        out = []
        for _f, cb, var in self.filas:
            prod = self._id(cb.get())
            if prod:
                out.append((prod, entero(var, 0, 99)))
        return out

    def _resumen(self):
        lineas = self.lineas()
        total = sum(c for _, c in lineas)
        productos = len({p for p, c in lineas if c > 0})
        self.lbl_total.configure(text=f"{total} cajas · {productos} productos")
        faltan, exced = entero(self.var_faltan), entero(self.var_excedentes)
        llegan = max(0, total - min(faltan, total)) + exced
        self.lbl_camion.configure(
            text=f"La orden dice {total} cajas. El camión traerá {llegan}: "
                 f"{min(faltan, total)} menos y {exced} de más.")

    def siguiente_documento(self):
        try:
            n = self.app.bd.contar("recepciones") + 1
        except Exception:
            n = 1
        self.var_doc.set(f"OC-{datetime.now():%Y%m%d}-{n:03d}")

    def iniciar(self):
        lineas = self.lineas()
        if not any(c > 0 for _, c in lineas):
            messagebox.showwarning("Orden vacía", "Agrega al menos un producto con cajas.")
            return
        doc = self.var_doc.get().strip() or f"OC-{datetime.now():%Y%m%d}"
        self.app.iniciar(doc, lineas, entero(self.var_faltan), entero(self.var_excedentes),
                         entero(self.var_danados), entero(self.var_cruces))

    def actualizar(self):
        en_curso = self.app.motor.en_curso()
        self.btn_iniciar.configure(state="disabled" if en_curso else "normal",
                                   text="Recepción en curso…" if en_curso else "Iniciar recepción")


# =====================================================================
# Utilidades para las tarjetas de tareas
# =====================================================================
class Tarjetas:
    def __init__(self, padre, fuentes, ancho=None):
        self.padre, self.f = padre, fuentes
        self.ancho = ancho or (lambda: 820)

    def nueva(self, titulo, color, subtitulo=None):
        marco = tk.Frame(self.padre, bg=COL["panel"], highlightthickness=1, highlightbackground=COL["linea"])
        tk.Frame(marco, bg=color, width=5).pack(side="left", fill="y")
        cuerpo = tk.Frame(marco, bg=COL["panel"], padx=12, pady=8)
        cuerpo.pack(side="left", fill="both", expand=True)
        cab = tk.Frame(cuerpo, bg=COL["panel"])
        cab.pack(fill="x")
        tk.Label(cab, text=titulo, bg=COL["panel"], fg=COL["texto"], font=self.f["negrita"], anchor="w").pack(side="left")
        if subtitulo:
            tk.Label(cab, text=subtitulo, bg=COL["panel"], fg=color, font=self.f["negrita"]).pack(side="left", padx=10)
        marco.pack(fill="x", padx=6, pady=5)
        return cuerpo

    def texto(self, padre, t, color=None, fuente="base"):
        lb = tk.Label(padre, text=t, bg=COL["panel"], fg=color or COL["texto"], font=self.f[fuente], anchor="w",
                      justify="left", wraplength=max(300, self.ancho()))
        lb.pack(fill="x", pady=(3, 0))
        return lb

    @staticmethod
    def botones(padre):
        f = tk.Frame(padre, bg=COL["panel"])
        f.pack(fill="x", pady=(8, 0))
        return f


# =====================================================================
# Pestaña Tareas: decisiones humanas pendientes
# =====================================================================
class TabTareas(ttk.Frame):
    def __init__(self, nb, app):
        super().__init__(nb, style="Panel.TFrame", padding=6)
        self.app = app
        self.cont = Desplazable(self, alto=200)
        self.cont.pack(fill="both", expand=True)
        self._ancho = 860
        self.t = Tarjetas(self.cont.interior, app.f, lambda: self._ancho - 70)
        self.cont.lienzo.bind("<Configure>", self._cambio_ancho, add="+")
        self.firma = None
        self.capturas = {}
        self.mensajes = {}
        self.var_conteo = tk.StringVar()

    def _cambio_ancho(self, e):
        if abs(e.width - self._ancho) > 30:
            self._ancho = e.width
            self.firma = None          # se reconstruyen las tarjetas con el nuevo ancho

    def pendientes(self):
        m = self.app.motor
        return (1 if m.fase in ("espera_aprobacion", "fin") else 0) + len(m.rev_a) + len(m.rev_b)

    def _firma(self):
        m = self.app.motor
        return (m.fase, m.folio,
                tuple((p, m.cajas[p].desvio["motivo"] if m.cajas[p].desvio else None) for p in m.rev_a),
                tuple(m.rev_b), tuple(sorted(self.mensajes.items())))

    def refrescar(self, forzar=False):
        m = self.app.motor
        if m.fase == "descarga":
            self.var_conteo.set(f"El IR de E1 lleva {m.conteo_ir} cajas contadas. La orden dice {m.esperadas}.")
        firma = self._firma()
        if firma == self.firma and not forzar:
            return
        self.firma = firma
        self.cont.limpiar()
        if m.fase == "sin_recepcion":
            c = self.t.nueva("No hay una recepción en curso", COL["acento"])
            self.t.texto(c, "Arma la orden de compra en el panel izquierdo, elige las fallas a simular y pulsa "
                            "«Iniciar recepción». Aquí aparecerán las decisiones que tiene que tomar una persona.")
        elif m.fase == "descarga":
            c = self.t.nueva(f"E1 · Descargando el camión de la recepción {m.folio}", COL["acento"], "BORRADOR")
            tk.Label(c, textvariable=self.var_conteo, bg=COL["panel"], fg=COL["texto"], font=self.app.f["base"],
                     anchor="w").pack(fill="x", pady=(3, 0))
            self.t.texto(c, "Cuando termine la descarga tendrás que aprobar o rechazar la entrega.", COL["texto2"], "chica")
        elif m.fase == "espera_aprobacion":
            self._tarjeta_aprobacion()
        elif m.fase == "cancelada":
            c = self.t.nueva(f"Recepción {m.folio} rechazada", COL["error"], "CANCELADA")
            self.t.texto(c, "Las cajas regresaron al proveedor. Puedes preparar otra orden en el panel izquierdo.")
        elif m.fase == "cerrada":
            c = self.t.nueva(f"Recepción {m.folio} cerrada", COL["ok"], "CERRADA")
            self.t.texto(c, "Todo quedó registrado en la base. Puedes vender cajas en la pestaña Venta de producto "
                            "o preparar otra orden en el panel izquierdo.")
        for pid in list(m.rev_a):
            self._tarjeta_rev_a(pid)
        for pid in list(m.rev_b):
            self._tarjeta_rev_b(pid)
        if m.fase == "linea" and not m.rev_a and not m.rev_b:
            c = self.t.nueva("La línea está trabajando", COL["ok"], "EN_PROCESO")
            self.t.texto(c, "Sin tareas por ahora. Si una caja se desvía a revisión A o B, aparecerá aquí. "
                            "La línea sigue corriendo mientras decides.")
        if m.fase == "fin":
            self._tarjeta_fin()

    # ------------------------------------------------------------ tarjetas
    def _tarjeta_aprobacion(self):
        m = self.app.motor
        dif = m.conteo_ir - m.esperadas
        c = self.t.nueva(f"E1 · Aprobar la recepción {m.folio}", COL["aviso"] if dif else COL["ok"],
                         "Diferencia en el conteo" if dif else "El conteo cuadra")
        self.t.texto(c, f"Documento {m.documento}. El IR contó {m.conteo_ir} cajas en la zona de espera y "
                        f"la orden dice {m.esperadas}.")
        if dif:
            self.t.texto(c, f"Diferencia de {dif:+d} cajas. Ya hay una incidencia DIFERENCIA_CONTEO_RECEPCION. "
                            "Si apruebas, la línea valida caja por caja qué producto llegó.", COL["aviso"])
        detalle = " · ".join(f"{p} {m.nombre(p)}: {n}" for p, n in m.lineas)
        self.t.texto(c, "Orden: " + detalle, COL["texto2"], "chica")
        b = self.t.botones(c)
        ttk.Button(b, text="Aprobar y pasar a la línea", style="Ok.TButton",
                   command=lambda: self.app.accion(m.aprobar)).pack(side="left")
        ttk.Button(b, text="Rechazar la entrega", style="Peligro.TButton",
                   command=self._rechazar).pack(side="left", padx=8)

    def _rechazar(self):
        if messagebox.askyesno("Rechazar la entrega", "La recepción quedará CANCELADA y las cajas regresan al "
                                                      "proveedor. ¿Rechazar?"):
            self.app.accion(self.app.motor.rechazar)

    def _tarjeta_rev_a(self, pid):
        m = self.app.motor
        caja = m.cajas[pid]
        d = caja.desvio
        if not d:
            return
        motivo = d["motivo"]
        c = self.t.nueva(f"Revisión A · caja #{pid}", COL["aviso"], MOTIVOS.get(motivo, motivo))
        leido = d.get("leido")
        if leido:
            prod = d.get("id_producto")
            self.t.texto(c, f"El lector E3 leyó el ID {leido}" + (f" ({prod} {m.nombre(prod)})." if prod else "."))
        else:
            self.t.texto(c, "El IR que sigue al lector de barras detectó la caja, pero el lector no entregó ningún código.")
        self.t.texto(c, f"El revisor ve la etiqueta del proveedor: {caja.codigo_barras}"
                        + (" (impresa pero dañada, se lee a ojo)." if not caja.legible else "."), COL["texto2"], "chica")
        self.t.texto(c, "Todavía no existe paquete ni movimiento de inventario para esta caja.", COL["texto2"], "chica")
        b = self.t.botones(c)
        if motivo in ("NO_ESPERADO", "EXCEDENTE"):
            ttk.Button(b, text="Aceptar la caja", style="Ok.TButton",
                       command=lambda: self._resolver_a(pid, "aceptar")).pack(side="left")
        else:
            var = self.capturas.setdefault(pid, tk.StringVar(value=caja.codigo_barras))
            tk.Label(b, text="ID capturado a mano", bg=COL["panel"], fg=COL["texto2"],
                     font=self.app.f["chica"]).pack(side="left")
            e = ttk.Entry(b, textvariable=var, width=14, font=self.app.f["mono"])
            e.pack(side="left", padx=6)
            e.bind("<Return>", lambda _e: self._resolver_a(pid, "capturar"))
            ttk.Button(b, text="Capturar ID", style="Ok.TButton",
                       command=lambda: self._resolver_a(pid, "capturar")).pack(side="left")
        ttk.Button(b, text="Devolver al proveedor", style="Peligro.TButton",
                   command=lambda: self._resolver_a(pid, "devolver")).pack(side="left", padx=8)
        if pid in self.mensajes:
            self.t.texto(c, self.mensajes[pid], COL["error"], "chica")

    def _resolver_a(self, pid, accion):
        m = self.app.motor
        if pid not in m.rev_a:
            return
        codigo = self.capturas[pid].get() if pid in self.capturas else None
        ok, res = self.app.accion(m.resolver_a, pid, accion, codigo)
        if not ok:
            return
        bien, msg = res
        if bien:
            self.mensajes.pop(pid, None)
            self.capturas.pop(pid, None)
        else:
            self.mensajes[pid] = "No se aceptó la captura: " + msg
        self.refrescar(forzar=True)

    def _tarjeta_rev_b(self, pid):
        m = self.app.motor
        caja = m.cajas[pid]
        d = caja.desvio
        if not d:
            return
        c = self.t.nueva(f"Revisión B · paquete {caja.epc}", COL["aviso"], MOTIVOS.get(d["motivo"], d["motivo"]))
        self.t.texto(c, f"Cuando el IR de E6 confirmó la caja se esperaba {caja.epc} y la antena leyó {d.get('leido') or 'nada'}. "
                        f"El paquete quedó RETENIDO en {self.app.cfg.UBIC_REVISION}.")
        self.t.texto(c, f"Al reetiquetar, el revisor escanea con el lector de mano el ID {caja.codigo_barras}, "
                        f"reimprime el tag {caja.epc} y la caja pasa al almacén.", COL["texto2"], "chica")
        b = self.t.botones(c)
        ttk.Button(b, text="Reetiquetar y almacenar", style="Ok.TButton",
                   command=lambda: self._resolver_b(pid, "reetiquetar")).pack(side="left")
        ttk.Button(b, text="Devolver al proveedor", style="Peligro.TButton",
                   command=lambda: self._resolver_b(pid, "devolver")).pack(side="left", padx=8)

    def _resolver_b(self, pid, accion):
        if pid in self.app.motor.rev_b:
            self.app.accion(self.app.motor.resolver_b, pid, accion)
            self.refrescar(forzar=True)

    def _tarjeta_fin(self):
        m = self.app.motor
        estado, difs = m.resultado_cierre or ("?", [])
        ok = estado == "VALIDADA"
        c = self.t.nueva(f"Línea terminada · recepción {m.folio}", COL["ok"] if ok else COL["aviso"], estado)
        if ok:
            self.t.texto(c, "Todo lo que pedía la orden llegó al almacén. No quedan incidencias abiertas.")
        else:
            for prod, esp, n in difs:
                signo = "faltan" if n < esp else "sobran"
                self.t.texto(c, f"{prod} {m.nombre(prod)}: se esperaban {esp} y hay {n} en almacén "
                                f"({signo} {abs(n - esp)}).", COL["aviso"])
            self.t.texto(c, "Cada diferencia quedó en la tabla incidencias, pendiente para compras (FALTANTE_PRODUCTO "
                            "o EXCEDENTE_RECIBIDO). Puedes verlas en la pestaña Base de datos.", COL["texto2"], "chica")
        b = self.t.botones(c)
        ttk.Button(b, text="Cerrar recepción", style="Acento.TButton",
                   command=lambda: self.app.accion(m.cerrar_recepcion)).pack(side="left")


# =====================================================================
# Pestaña Conciliación y existencias
# =====================================================================
class TabConciliacion(ttk.Frame):
    def __init__(self, nb, app):
        super().__init__(nb, style="Panel.TFrame", padding=8)
        self.app = app
        pw = ttk.PanedWindow(self, orient="horizontal")
        pw.pack(fill="both", expand=True)
        izq = ttk.Frame(pw, style="Panel.TFrame")
        der = ttk.Frame(pw, style="Panel.TFrame")
        pw.add(izq, weight=3)
        pw.add(der, weight=2)
        self._sash_listo = False
        pw.bind("<Configure>", lambda e: self._sash(pw), add="+")
        ttk.Label(izq, text="Orden contra lo que registró la línea", style="Seccion.TLabel").pack(anchor="w")
        self.lbl = ttk.Label(izq, text="", style="Sub.TLabel", wraplength=560, justify="left")
        self.lbl.pack(anchor="w", pady=(2, 4))
        izq.bind("<Configure>", lambda e: self.lbl.configure(wraplength=max(250, e.width - 10)))
        marco, self.conc = arbol_con_barras(
            izq, ("prod", "orden", "alm", "dif", "acep", "ret", "dev"),
            ("Producto", "Orden", "Almacén", "Diferencia", "Aceptadas", "Revisión B", "Devueltas"),
            (150, 56, 66, 76, 74, 80, 74))
        marco.pack(fill="both", expand=True)
        # Cada número ocupa lo justo para su encabezado; el producto toma el espacio que sobra
        f_cab = tkfont.Font(font=app.f["negrita_chica"])
        for col in ("orden", "alm", "dif", "acep", "ret", "dev"):
            self.conc.column(col, width=f_cab.measure(self.conc.heading(col, "text")) + 10, stretch=False)
        self.conc.column("prod", width=100, minwidth=80, stretch=True)
        ttk.Label(der, text="Inventario por ubicación", style="Seccion.TLabel").pack(anchor="w")
        self.var_cero = tk.BooleanVar(value=True)
        ttk.Checkbutton(der, text="Ocultar productos en cero", variable=self.var_cero, command=self.refrescar,
                        style="Panel.TCheckbutton").pack(anchor="w", pady=(2, 4))
        self.ubics = [app.cfg.UBIC_RECEPCION, app.cfg.UBIC_ALMACEN, app.cfg.UBIC_REVISION]
        marco, self.exist = arbol_con_barras(der, ["prod"] + self.ubics, ["Producto"] + self.ubics,
                                             [100] + [52] * len(self.ubics))
        marco.pack(fill="both", expand=True)
        self._f_cab = f_cab
        self._columnas_inventario()

    def _columnas_inventario(self):
        """Cada ubicación ocupa lo justo para su encabezado; el producto toma lo que sobra."""
        for u in self.ubics:
            self.exist.column(u, width=self._f_cab.measure(u) + 12, minwidth=40, stretch=False, anchor="w")
        self.exist.column("prod", width=100, minwidth=80, stretch=True)

    def _sash(self, pw):
        ancho = pw.winfo_width()
        if not self._sash_listo and ancho > 700:
            pw.sashpos(0, max(400, ancho - max(280, int(ancho * 0.35))))
            self._sash_listo = True

    def refrescar(self):
        m = self.app.motor
        bd = self.app.bd
        self.conc.delete(*self.conc.get_children())
        if m.id_rec:
            final = m.fase in ("fin", "cerrada")
            tot = [0, 0, 0, 0, 0, 0]
            for i, r in enumerate(bd.conciliacion(m.id_rec)):
                esp, acep, alm, ret, dev, vend = (int(v) for v in r[2:8])
                for j, v in enumerate((esp, acep, alm, ret, dev, vend)):
                    tot[j] += v
                dif = alm - esp
                tag = ("ok" if dif == 0 else "aviso" if dif > 0 else "error") if final else ("par" if i % 2 else "")
                self.conc.insert("", "end", values=(f"{r[0]} {r[1]}", esp, alm,
                                                    (f"{dif:+d}" if dif else "0") if final else "…", acep, ret, dev),
                                 tags=(tag,))
            texto = (f"Recepción {m.folio}: el IR de E1 contó {m.conteo_ir}, la orden pide {tot[0]}, la línea aceptó "
                     f"{tot[1]}, llegaron {tot[2]} al almacén, {tot[3]} están en revisión B y {tot[4]} se devolvieron.")
            if tot[5]:
                texto += (f" De las que llegaron al almacén, {tot[5]} "
                          + ("ya se vendió." if tot[5] == 1 else "ya se vendieron."))
            if not final:
                texto += " La diferencia se calcula al terminar la línea."
            else:
                texto += " Una caja devuelta en revisión A no aparece aquí porque nunca se registró como paquete."
            self.lbl.configure(text=texto)
        else:
            self.lbl.configure(text="Todavía no hay una recepción en esta sesión.")
        tabla = {}
        for prod, nombre, ubic, fisica, _res, _disp in bd.existencias():
            fila = tabla.setdefault((prod, nombre), {})
            fila[ubic] = int(fisica)
            if ubic not in self.ubics:
                self.ubics.append(ubic)
                self.exist["columns"] = ["prod"] + self.ubics
                self.exist.heading("prod", text="Producto", anchor="w")
                for u in self.ubics:
                    self.exist.heading(u, text=u, anchor="w")
                self._columnas_inventario()
        self.exist.delete(*self.exist.get_children())
        i = 0
        for (prod, nombre), fila in sorted(tabla.items()):
            if self.var_cero.get() and not any(fila.values()):
                continue
            self.exist.insert("", "end", values=[f"{prod} {nombre}"] + [fila.get(u, 0) for u in self.ubics],
                              tags=("par",) if i % 2 else ())
            i += 1


# =====================================================================
# Pestaña Base de datos: las tablas que se pueden consultar en vivo
# =====================================================================
AYUDA_BD = {
    "recepciones": "Una fila por camión recibido: folio, proveedor, documento y estado de la recepción.",
    "detalle_recepcion": "Lo que dice la orden de compra: cajas esperadas de cada producto en cada recepción.",
    "existencias": "Tabla paquetes. id_recepcion es la recepción (camión) en la que entró la caja y folio_recepcion, "
                   "su folio. Al venderla: VENDIDO.",
    "eventos_iot": "Cada lectura o detección de un sensor o máquina de la línea, del mostrador y de la revisión.",
    "incidencias": "Cada problema que encontró la línea, su motivo y en qué estado quedó.",
    "ordenes_trabajo": "Las ventas: una orden SURTIDO por cada caja vendida.",
    "dispositivos_iot": "Los sensores, lectores, desviadores e impresoras que escriben en eventos_iot.",
    "productos": "El catálogo de productos.",
}
COLOR_ESTADO = {"VENDIDO": "ok", "RETENIDO": "aviso", "DEVUELTO": "error"}


class TabBD(ttk.Frame):
    def __init__(self, nb, app):
        super().__init__(nb, style="Panel.TFrame", padding=8)
        self.app = app
        arriba = ttk.Frame(self, style="Panel.TFrame")
        arriba.pack(fill="x")
        ttk.Label(arriba, text="Tabla", style="Panel.TLabel").pack(side="left")
        self.var = tk.StringVar(value="existencias")
        cb = ttk.Combobox(arriba, textvariable=self.var, values=list(VISTAS_BD), state="readonly", width=20)
        cb.pack(side="left", padx=6)
        cb.bind("<<ComboboxSelected>>", lambda e: self.refrescar())
        ttk.Button(arriba, text="Actualizar", command=self.refrescar).pack(side="left")
        self.var_auto = tk.BooleanVar(value=True)
        ttk.Checkbutton(arriba, text="Actualizar sola", variable=self.var_auto, style="Panel.TCheckbutton").pack(
            side="left", padx=10)
        self.lbl = ttk.Label(arriba, text="", style="Sub.TLabel")
        self.lbl.pack(side="right")
        self.lbl_ayuda = ttk.Label(self, text="", style="Sub.TLabel", wraplength=1000, justify="left")
        self.lbl_ayuda.pack(anchor="w", pady=(4, 4))
        self.bind("<Configure>", lambda e: self.lbl_ayuda.configure(wraplength=max(300, e.width - 20)), add="+")
        self.marco, self.arbol = arbol_con_barras(self, ("x",), ("",), (100,), alto=10)
        self.marco.pack(fill="both", expand=True)
        self._cols = None
        self._fuente = tkfont.Font(font=app.f["chica"])
        self._fuente_cab = tkfont.Font(font=app.f["negrita_chica"])

    def refrescar(self):
        nombre = self.var.get()
        cols, filas = self.app.bd.tabla(nombre, 200)
        total = self.app.bd.contar(nombre)
        y = self.arbol.yview()[0] if cols == self._cols else 0
        self.arbol.delete(*self.arbol.get_children())
        textos = [[fmt(v) for v in r] for r in filas]
        if cols != self._cols:
            self.arbol["columns"] = cols
            for i, c in enumerate(cols):
                ancho = max([self._fuente_cab.measure(c)] + [self._fuente.measure(t[i]) for t in textos[:40]]) + 18
                self.arbol.heading(c, text=c, anchor="w")
                self.arbol.column(c, width=max(60, min(300, ancho)), minwidth=40, stretch=False, anchor="w")
            self._cols = cols
        i_estado = cols.index("estado_validacion") if "estado_validacion" in cols else None
        for i, t in enumerate(textos):
            tag = COLOR_ESTADO.get(t[i_estado]) if i_estado is not None else None
            self.arbol.insert("", "end", values=t, tags=(tag,) if tag else ("par",) if i % 2 else ())
        self.arbol.yview_moveto(y)
        self.lbl.configure(text=f"{total} filas" + (f" · mostrando las {len(filas)} más recientes" if total > len(filas) else ""))
        self.lbl_ayuda.configure(text=AYUDA_BD.get(nombre, ""))

    def auto(self):
        return self.var_auto.get()


# =====================================================================
# Pestaña Venta de producto: lector RFID de mano en el mostrador
# =====================================================================
class TabVenta(ttk.Frame):
    CAMPOS = (("id_producto", "Producto"), ("nombre", "Contenido"), ("unidad_medida", "Unidad"),
              ("estado_validacion", "Estado del paquete"), ("folio", "Recepción"),
              ("documento_proveedor", "Documento"), ("proveedor", "Proveedor"),
              ("fecha_registro", "Registrado"), ("orden_venta", "Orden de venta"))

    def __init__(self, nb, app):
        super().__init__(nb, style="Panel.TFrame", padding=10)
        self.app = app
        ttk.Label(self, text="Mostrador: escanea el tag RFID de una caja del almacén para ver qué contiene y venderla.",
                  style="Panel.TLabel").pack(anchor="w")
        f = ttk.Frame(self, style="Panel.TFrame")
        f.pack(fill="x", pady=8)
        ttk.Label(f, text="Tag (EPC)", style="Panel.TLabel").pack(side="left")
        self.cb = ttk.Combobox(f, width=36, font=app.f["mono"])
        self.cb.pack(side="left", padx=6)
        self.cb.bind("<Return>", lambda e: self.escanear())
        ttk.Button(f, text="Actualizar lista", command=self.refrescar).pack(side="left")
        ttk.Button(f, text="Escanear tag", style="Acento.TButton", command=self.escanear).pack(side="left", padx=8)
        self.btn_vender = ttk.Button(f, text="Registrar venta", style="Ok.TButton", command=self.vender,
                                     state="disabled")
        self.btn_vender.pack(side="left")
        self.lbl_disp = ttk.Label(self, text="", style="Sub.TLabel")
        self.lbl_disp.pack(anchor="w")
        self.ficha = tk.Frame(self, bg=COL["panel"], highlightthickness=1, highlightbackground=COL["linea"],
                              padx=14, pady=10)
        self.ficha.pack(anchor="w", pady=8, fill="x")
        self.vars = {}
        for i, (k, t) in enumerate(self.CAMPOS):
            tk.Label(self.ficha, text=t, bg=COL["panel"], fg=COL["texto2"], font=app.f["chica"]).grid(
                row=i // 3, column=(i % 3) * 2, sticky="w", padx=(0, 8), pady=2)
            v = tk.StringVar(value="—")
            tk.Label(self.ficha, textvariable=v, bg=COL["panel"], fg=COL["texto"], font=app.f["negrita"]).grid(
                row=i // 3, column=(i % 3) * 2 + 1, sticky="w", padx=(0, 22), pady=2)
            self.vars[k] = v
        self.lbl_res = ttk.Label(self, text="", style="Panel.TLabel", wraplength=900, justify="left")
        self.lbl_res.pack(anchor="w")
        self.actual = None

    def _epc(self):
        return self.cb.get().split(" · ")[0].strip()

    def refrescar(self):
        filas = self.app.bd.paquetes_en_almacen()
        self.cb["values"] = [f"{e} · {p} {n}" for e, p, n in filas]
        self.lbl_disp.configure(text=f"{len(filas)} cajas disponibles en {self.app.cfg.UBIC_ALMACEN}.")
        if not self.cb.get() and filas:
            self.cb.set(self.cb["values"][0])

    def escanear(self):
        epc = self._epc()
        if not epc:
            return
        ok, info = self.app.accion(self.app.motor.consultar_tag, epc, animar=False)
        if not ok:
            return
        self.actual = info
        if not info:
            for v in self.vars.values():
                v.set("—")
            self.lbl_res.configure(text=f"El tag {epc} no está registrado en paquetes. La lectura quedó en eventos_iot.",
                                   foreground=COL["error"])
            self.btn_vender.configure(state="disabled")
            return
        for k, v in self.vars.items():
            val = info.get(k)
            v.set("—" if val is None else fmt(val))
        estado = info["estado_validacion"]
        disponible = estado == "ALMACENADO"
        self.btn_vender.configure(state="normal" if disponible else "disabled")
        if disponible:
            texto = "Caja disponible para venta."
        elif estado == "VENDIDO":
            texto = f"Esta caja ya se vendió con la orden {info['orden_venta'] or '—'}."
        else:
            texto = f"Esta caja no se puede vender: no está en el almacén (estado {estado})."
        self.lbl_res.configure(text=texto, foreground=COL["ok"] if disponible else COL["aviso"])

    def vender(self):
        epc = self._epc()
        ok, folio = self.app.accion(self.app.motor.vender, epc, animar=True)
        if ok:
            self.lbl_res.configure(text=f"Venta registrada: orden de trabajo {folio} (SURTIDO, COMPLETADA). El paquete "
                                        f"pasó a VENDIDO y salió de {self.app.cfg.UBIC_ALMACEN}.",
                                   foreground=COL["ok"])
            self.btn_vender.configure(state="disabled")
            self.vars["estado_validacion"].set("VENDIDO")
            self.vars["orden_venta"].set(folio)
            self.cb.set("")
            self.refrescar()


# =====================================================================
# Pestaña Bitácora
# =====================================================================
class TabBitacora(ttk.Frame):
    def __init__(self, nb, app):
        super().__init__(nb, style="Panel.TFrame", padding=6)
        self.app = app
        self.txt = tk.Text(self, bg=COL["panel"], fg=COL["texto"], font=app.f["chica"], relief="flat", wrap="word",
                           padx=8, pady=6, highlightthickness=1, highlightbackground=COL["linea"])
        barra = ttk.Scrollbar(self, orient="vertical", command=self.txt.yview)
        self.txt.configure(yscrollcommand=barra.set, state="disabled")
        self.txt.pack(side="left", fill="both", expand=True)
        barra.pack(side="right", fill="y")
        self.txt.tag_configure("hora", foreground=COL["texto2"], font=app.f["mono_chica"])
        self.txt.tag_configure("etapa", foreground=COL["acento"], font=app.f["negrita"])
        self.txt.tag_configure("ok", foreground=COL["ok"])
        self.txt.tag_configure("warn", foreground=COL["aviso"])
        self.txt.tag_configure("crit", foreground=COL["error"])
        self.txt.tag_configure("info", foreground=COL["texto"])
        self.mostradas = 0

    def refrescar(self):
        m = self.app.motor
        nuevas = m.log_total - self.mostradas
        if nuevas <= 0:
            return
        abajo = self.txt.yview()[1] > 0.98 if self.winfo_ismapped() else True
        self.txt.configure(state="normal")
        for hora, etapa, texto, nivel in m.bitacora[-min(nuevas, len(m.bitacora)):]:
            self.txt.insert("end", hora + "  ", "hora")
            self.txt.insert("end", f"{etapa:<6} ", "etapa")
            self.txt.insert("end", texto + "\n", nivel)
        self.mostradas = m.log_total
        lineas = int(self.txt.index("end-1c").split(".")[0])
        if lineas > 1500:
            self.txt.delete("1.0", f"{lineas - 1200}.0")
        self.txt.configure(state="disabled")
        if abajo:
            self.txt.see("end")

    def al_final(self):
        self.txt.see("end")
