"""Colores claros y estilos de la interfaz."""
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk

COL = {
    "fondo": "#F3F6F7", "panel": "#FFFFFF", "panel2": "#EDF2F4", "texto": "#1F2B31", "texto2": "#5B6B73",
    "linea": "#D3DCE0", "acento": "#1C6C8A", "acento_claro": "#D9EDF4",
    "ok": "#2E8350", "ok_claro": "#E2F2E8", "aviso": "#9A6200", "aviso_claro": "#FCEFD6",
    "error": "#B9382A", "error_claro": "#F9E2DE",
    "banda": "#CBD4D9", "banda_raya": "#B7C2C8", "rodillo": "#9AA7AE", "chute": "#B9C5CB",
    "kraft": "#DDB57E", "kraft_borde": "#A9824C", "etiqueta": "#FFFFFF", "barras": "#1F2B31",
    "ir": "#D0443A", "peligro": "#E3A60B", "tag": "#1C6C8A",
}

# Un color por producto (franja de la caja), en el orden del catálogo
COLORES_PRODUCTO = ["#2F5DA8", "#B23A3A", "#3B7D3A", "#6B4C9A", "#C0661C", "#13808A", "#8A6512", "#A23E7A",
                    "#4F6D7A", "#7A8B1F", "#B5524A", "#3E5C9A", "#5A7F5E", "#9C5B2E", "#6A5ACD", "#2E7D6B"]


def elegir_fuente(preferidas):
    disponibles = set(tkfont.families())
    for f in preferidas:
        if f in disponibles:
            return f
    return "TkDefaultFont"


def aplicar_estilo(root):
    base = elegir_fuente(["Segoe UI", "Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans"])
    mono = elegir_fuente(["Consolas", "Menlo", "DejaVu Sans Mono", "Courier New"])
    fuentes = {
        "base": (base, 10), "chica": (base, 9), "negrita": (base, 10, "bold"), "titulo": (base, 13, "bold"),
        "seccion": (base, 10, "bold"), "mono": (mono, 9), "mono_chica": (mono, 8), "grande": (base, 18, "bold"),
        "mini": (base, 8), "mini_negrita": (base, 8, "bold"), "negrita_chica": (base, 9, "bold"),
    }
    root.configure(bg=COL["fondo"])
    for nombre in ("TkDefaultFont", "TkTextFont", "TkMenuFont"):
        try:
            tkfont.nametofont(nombre).configure(family=base, size=10)
        except tk.TclError:
            pass
    s = ttk.Style(root)
    s.theme_use("clam")
    s.configure(".", background=COL["fondo"], foreground=COL["texto"], font=fuentes["base"],
                bordercolor=COL["linea"], lightcolor=COL["panel"], darkcolor=COL["linea"], troughcolor=COL["panel2"])
    s.configure("TFrame", background=COL["fondo"])
    s.configure("Panel.TFrame", background=COL["panel"])
    s.configure("TLabel", background=COL["fondo"], foreground=COL["texto"])
    s.configure("Panel.TLabel", background=COL["panel"])
    s.configure("Sub.TLabel", background=COL["panel"], foreground=COL["texto2"], font=fuentes["chica"])
    s.configure("Seccion.TLabel", background=COL["panel"], foreground=COL["acento"], font=fuentes["seccion"])
    s.configure("Titulo.TLabel", background=COL["fondo"], font=fuentes["titulo"])
    s.configure("TLabelframe", background=COL["panel"], bordercolor=COL["linea"])
    s.configure("TLabelframe.Label", background=COL["panel"], foreground=COL["acento"], font=fuentes["seccion"])
    s.configure("TButton", background=COL["panel2"], foreground=COL["texto"], padding=(10, 5), relief="flat")
    s.map("TButton", background=[("disabled", COL["panel2"]), ("active", COL["acento_claro"])],
          foreground=[("disabled", "#A3B0B6")])
    s.configure("Acento.TButton", background=COL["acento"], foreground="#FFFFFF")
    s.map("Acento.TButton", background=[("disabled", "#9DBFCB"), ("active", "#24809F")], foreground=[("disabled", "#F2F6F7")])
    s.configure("Ok.TButton", background=COL["ok"], foreground="#FFFFFF")
    s.map("Ok.TButton", background=[("disabled", "#A9CDB6"), ("active", "#38975F")], foreground=[("disabled", "#F2F6F7")])
    s.configure("Peligro.TButton", background=COL["error_claro"], foreground=COL["error"])
    s.map("Peligro.TButton", background=[("disabled", COL["panel2"]), ("active", "#F3CFC9")])
    s.configure("TCheckbutton", background=COL["fondo"])
    s.configure("Panel.TCheckbutton", background=COL["panel"])
    s.map("TCheckbutton", background=[("active", COL["panel2"])])
    s.map("Panel.TCheckbutton", background=[("active", COL["panel2"])])
    s.configure("TNotebook", background=COL["fondo"], bordercolor=COL["linea"])
    s.configure("TNotebook.Tab", background=COL["panel2"], foreground=COL["texto2"], padding=(12, 5))
    s.map("TNotebook.Tab", background=[("selected", COL["panel"])], foreground=[("selected", COL["acento"])])
    alto_fila = tkfont.Font(root=root, font=fuentes["chica"]).metrics("linespace") + 8
    s.configure("Treeview", background=COL["panel"], fieldbackground=COL["panel"], foreground=COL["texto"],
                rowheight=max(22, alto_fila), font=fuentes["chica"])
    s.configure("Treeview.Heading", background=COL["panel2"], foreground=COL["texto2"], font=fuentes["negrita_chica"])
    s.map("Treeview", background=[("selected", COL["acento_claro"])], foreground=[("selected", COL["texto"])])
    s.configure("TCombobox", fieldbackground=COL["panel"], background=COL["panel2"])
    s.configure("TEntry", fieldbackground=COL["panel"])
    s.configure("TSpinbox", fieldbackground=COL["panel"], arrowsize=12)
    s.configure("TScale", background=COL["fondo"])
    return fuentes


def etiquetar_arbol(arbol):
    """Colores de fila para estados en las tablas."""
    arbol.tag_configure("ok", background=COL["ok_claro"])
    arbol.tag_configure("aviso", background=COL["aviso_claro"])
    arbol.tag_configure("error", background=COL["error_claro"])
    arbol.tag_configure("par", background="#F8FAFB")


class Desplazable(ttk.Frame):
    """Marco con barra de desplazamiento vertical. La rueda del mouse mueve
    el marco que está bajo el puntero (Windows, macOS y Linux)."""
    _todos = []
    _enlazado = False

    def __init__(self, padre, alto=240, **kw):
        super().__init__(padre, style="Panel.TFrame", **kw)
        self.lienzo = tk.Canvas(self, bg=COL["panel"], highlightthickness=0, height=alto)
        barra = ttk.Scrollbar(self, orient="vertical", command=self.lienzo.yview)
        self.interior = ttk.Frame(self.lienzo, style="Panel.TFrame")
        self.interior.bind("<Configure>", lambda e: self.lienzo.configure(scrollregion=self.lienzo.bbox("all")))
        self._win = self.lienzo.create_window((0, 0), window=self.interior, anchor="nw")
        self.lienzo.bind("<Configure>", lambda e: self.lienzo.itemconfigure(self._win, width=e.width))
        self.lienzo.configure(yscrollcommand=barra.set)
        self.lienzo.pack(side="left", fill="both", expand=True)
        barra.pack(side="right", fill="y")
        Desplazable._todos.append(self)
        if not Desplazable._enlazado:
            for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                self.bind_all(ev, Desplazable._rueda_global, add="+")
            Desplazable._enlazado = True

    @staticmethod
    def _rueda_global(e):
        if getattr(e, "num", None) == 4:
            unidades = -1
        elif getattr(e, "num", None) == 5:
            unidades = 1
        else:
            unidades = int(-e.delta / 120) or (-1 if e.delta > 0 else 1)
        vivos = []
        for d in Desplazable._todos:
            try:
                if d.winfo_exists():
                    vivos.append(d)
            except tk.TclError:
                pass
        Desplazable._todos = vivos
        if not vivos:
            return
        try:
            w = vivos[0].winfo_containing(e.x_root, e.y_root)
        except (KeyError, tk.TclError):
            return
        if w is None:
            return
        ruta = str(w)
        for d in vivos:
            if ruta == str(d) or ruta.startswith(str(d) + "."):
                d._mover(unidades)
                return

    def _mover(self, unidades):
        if self.lienzo.yview() != (0.0, 1.0):
            self.lienzo.yview_scroll(unidades, "units")

    def limpiar(self):
        for w in self.interior.winfo_children():
            w.destroy()
