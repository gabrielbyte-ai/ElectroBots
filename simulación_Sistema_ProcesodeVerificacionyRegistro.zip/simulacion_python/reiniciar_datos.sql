-- =====================================================================
-- OPCIONAL: deja papeleria_db lista para repetir la demostración.
--
-- CUIDADO: BORRA TODAS las recepciones, paquetes, eventos IoT,
-- movimientos, incidencias, revisiones, órdenes de trabajo y auditoría
-- de la base, no solo las de la simulación, y pone las existencias en 0.
--
-- No toca proveedores, productos, ubicaciones, dispositivos_iot,
-- la numeración (codigo_proveedor) ni sincronizacion_outbox.
-- La simulación nunca lo ejecuta: córrelo tú solo si quieres empezar
-- de cero (por ejemplo desde pgAdmin o con psql).
-- =====================================================================
BEGIN;
DELETE FROM revisiones_humanas;
DELETE FROM incidencias;
DELETE FROM movimientos_inventario;
DELETE FROM detalle_orden_trabajo;
DELETE FROM ordenes_trabajo;
DELETE FROM detalle_paquete;
DELETE FROM paquetes;
DELETE FROM detalle_recepcion;
DELETE FROM recepciones;
DELETE FROM eventos_iot;
DELETE FROM auditoria;
UPDATE existencias SET cantidad = 0, cantidad_reservada = 0, fecha_actualizacion = NOW();
COMMIT;
