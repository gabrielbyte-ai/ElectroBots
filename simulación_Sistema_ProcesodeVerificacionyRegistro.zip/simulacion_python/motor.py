"""Motor de la simulación: lo que pasa físicamente en las bandas y cuándo se escribe en la base.

La 'verdad física' (qué trae cada caja, si su código está dañado, qué tag le pegaron)
solo vive aquí en memoria. La base de datos recibe únicamente lo que leen los sensores
y lo que deciden las personas, igual que en la planta real."""
import random
from datetime import datetime

RN, R_IR = 7, 5            # banda de recepción: 7 tramos, sensor IR en el tramo 5
N = 18                     # línea principal: 18 tramos
# Cada IR de E3 y E6 va DESPUÉS de su lector: el lector lee y el IR que sigue confirma la caja.
# E5 es una sola máquina automática (ETQ): imprime, codifica y pega el tag RFID.
P = {"CAM": 3, "IR3": 4, "D1": 5, "REINS": 7, "ETQ": 9, "RDR": 13, "IR6": 14, "D2": 15}

MOTIVOS = {
    "SIN_LECTURA": "Sin lectura de código",
    "FORMATO": "ID con formato inválido",
    "CODIGO_DESCONOCIDO": "Numeración de producto desconocida",
    "DUPLICADO": "ID repetido",
    "NO_ESPERADO": "Producto que no viene en la recepción",
    "EXCEDENTE": "Caja excedente",
    "RFID_SIN_LECTURA": "Tag RFID sin lectura",
    "RFID_NO_COINCIDE": "El EPC leído no coincide",
    "RFID_DUPLICADO": "EPC repetido",
}


class Caja:
    def __init__(self, pid, codigo_prov, id_producto, nombre, codigo_barras, legible, cruce, folio):
        self.pid = pid
        self.codigo_prov = codigo_prov        # numeración del contenido (verdad física)
        self.id_producto = id_producto        # contenido real
        self.nombre = nombre
        self.codigo_barras = codigo_barras    # ID impreso en la etiqueta del proveedor
        self.legible = legible
        self.cruce = cruce                    # a esta caja le toca un cruce de tags
        self.folio_rec = folio
        self.loc = "camion"
        self.id_paquete = None                # lo que sabe el sistema
        self.epc = None
        self.id_producto_sis = None
        self.codigo_leido = None
        self.lectura = None                   # código que entregó el lector, esperando al IR
        self.lectura_rfid = None              # tag que leyó la antena, esperando al IR
        self.tag = None                       # tag que físicamente trae pegado
        self.tag_forzado = None
        self.desvio = None
        self.verdad = ["Código de barras dañado"] if not legible else []


class Motor:
    def __init__(self, bd, cfg):
        self.bd, self.cfg = bd, cfg
        self.rng = random.Random()
        self.cajas = {}
        self.pid_seq = 0
        self.bitacora = []
        self.log_total = 0          # entradas escritas desde el inicio (la bitácora se recorta)
        self.fase = "sin_recepcion"
        self.id_rec = self.folio = None
        self.lineas = []
        self.cargar_catalogo(cfg.PROVEEDOR_POR_DEFECTO)
        self._limpiar()

    # ------------------------------------------------------------- utilidades
    def cargar_catalogo(self, id_proveedor):
        self.id_proveedor = id_proveedor
        cat = self.bd.catalogo(id_proveedor)
        self.catalogo = {c["id_producto"]: c for c in cat}
        self.por_codigo = {c["codigo_proveedor"]: c["id_producto"] for c in cat if c["codigo_proveedor"]}

    def _limpiar(self):
        self.camion, self.espera, self.rev_a, self.rev_b, self.reingreso = [], [], [], [], []
        self.banda_rec = [None] * RN
        self.linea = [None] * N
        self.conteo_ir = self.detectadas = self.tick = self.cruces_pend = 0
        self.ultima_carga = -99
        self.leidos_rfid = set()
        self.id_incid_conteo = None
        self.resultado_cierre = None
        self.flash = {}

    def log(self, etapa, texto, nivel="info"):
        self.bitacora.append((datetime.now().strftime("%H:%M:%S"), etapa, texto, nivel))
        self.log_total += 1
        if len(self.bitacora) > 600:
            del self.bitacora[:200]

    def nombre(self, id_producto):
        c = self.catalogo.get(id_producto)
        return c["nombre"] if c else (id_producto or "?")

    def en_curso(self):
        return self.fase in ("descarga", "espera_aprobacion", "linea")

    # ------------------------------------------------------- nueva recepción
    def nueva_recepcion(self, documento, lineas, faltan, excedentes, danados, cruces):
        """lineas: [(id_producto, cajas)]. Crea la recepción en BORRADOR y llena el camión."""
        if self.en_curso():
            raise RuntimeError("Termina la recepción en curso antes de iniciar otra.")
        juntas = {}
        for prod, cajas in lineas:
            if cajas > 0:
                juntas[prod] = juntas.get(prod, 0) + cajas
        lineas = list(juntas.items())
        if not lineas:
            raise ValueError("La orden no tiene cajas.")
        sin_codigo = [p for p, _ in lineas if not self.catalogo[p]["codigo_proveedor"]]
        if sin_codigo:
            raise ValueError("Estos productos no tienen numeración (codigo_proveedor): " + ", ".join(sin_codigo))
        self._limpiar()
        self.lineas, self.documento = lineas, documento
        self.esperadas = sum(c for _, c in lineas)
        self.id_rec, self.folio = self.bd.crear_recepcion(self.id_proveedor, documento, lineas)
        base = (self.bd.contar("recepciones") % 1000) * 1000 + 1

        # Lo que realmente trae el camión
        lista = [p for p, c in lineas for _ in range(c)]
        for _ in range(min(faltan, len(lista))):
            lista.pop(self.rng.randrange(len(lista)))
        for _ in range(excedentes):
            lista.append(self.rng.choice(lineas)[0])
        self.rng.shuffle(lista)
        idx = list(range(len(lista)))
        self.rng.shuffle(idx)
        danadas = set(idx[:min(danados, len(lista))])
        cruzadas = set([i for i in idx if i not in danadas and i < len(lista) - 1][:min(cruces, len(lista) // 2)])
        for i, prod in enumerate(lista):
            self.pid_seq += 1
            cod = self.catalogo[prod]["codigo_proveedor"]
            caja = Caja(self.pid_seq, cod, prod, self.nombre(prod), f"{cod}{base + i:06d}",
                        i not in danadas, i in cruzadas, self.folio)
            self.cajas[caja.pid] = caja
            self.camion.append(caja.pid)
        self.fase = "descarga"
        self.log("E1", f"Llega el camión con el documento {documento}. Se esperan {self.esperadas} cajas. "
                       f"Recepción {self.folio} en BORRADOR.")

    # ------------------------------------------------------------- un paso
    def paso(self):
        """Avanza la banda un tramo. Devuelve False si no hay nada que mover."""
        if self.fase == "descarga":
            self.tick += 1
            self.flash = {}
            self._paso_recepcion()
            return True
        if self.fase == "linea":
            if self._linea_vacia():
                self._revisar_fin()
                return False
            self.tick += 1
            self.flash = {}
            self._paso_linea()
            return True
        return False

    def _paso_recepcion(self):
        sale = self.banda_rec[-1]
        self.banda_rec = [None] + self.banda_rec[:-1]
        if sale:
            self.cajas[sale].loc = "espera"
            self.espera.append(sale)
        if self.banda_rec[R_IR]:
            self.conteo_ir += 1
            self.bd.conteo_ir(self.folio, self.conteo_ir)
            self.flash["ir_rec"] = "on"
        if self.camion and self.tick % 2 == 0:
            pid = self.camion.pop(0)
            self.cajas[pid].loc = "banda_rec"
            self.banda_rec[0] = pid
        if not self.camion and not any(self.banda_rec):
            self.id_incid_conteo = self.bd.fin_conteo(self.id_rec, self.esperadas, self.conteo_ir)
            self.fase = "espera_aprobacion"
            dif = self.conteo_ir - self.esperadas
            self.log("E1", f"Descarga terminada. El IR contó {self.conteo_ir} cajas y se esperan {self.esperadas}."
                     + (f" Diferencia: {dif:+d}. Se creó una incidencia." if dif else ""), "warn" if dif else "ok")

    def aprobar(self):
        if self.fase != "espera_aprobacion":
            return
        self.bd.aprobar_recepcion(self.id_rec, self.folio, self.id_incid_conteo)
        self.fase = "linea"
        self.log("E1", f"Recepción {self.folio} aprobada. Estado EN_PROCESO: la línea ya acepta cajas.", "ok")

    def rechazar(self):
        if self.fase != "espera_aprobacion":
            return
        self.bd.rechazar_recepcion(self.id_rec, self.folio, self.id_incid_conteo, self.esperadas, self.conteo_ir)
        for pid in self.espera:
            self.cajas[pid].loc = "devuelta"
        self.espera = []
        self.fase = "cancelada"
        self.log("E1", f"Recepción {self.folio} rechazada (CANCELADA). Las cajas regresan al camión.", "crit")

    def _linea_vacia(self):
        return not self.espera and not any(self.linea) and not self.reingreso

    def _paso_linea(self):
        sale = self.linea[-1]
        self.linea = [None] + self.linea[:-1]
        if sale:
            self._al_almacen(sale)
        for pos, fn in ((P["D2"], self._d2), (P["IR6"], self._ir_e6), (P["RDR"], self._lector_rfid),
                        (P["ETQ"], self._etiquetar), (P["D1"], self._d1),
                        (P["IR3"], self._ir_e3), (P["CAM"], self._lector_barras)):
            pid = self.linea[pos]
            if pid:
                fn(pid)
        r = P["REINS"]
        if self.reingreso and not self.linea[r - 1] and not self.linea[r] and not self.linea[r + 1]:
            pid = self.reingreso.pop(0)
            self.linea[r] = pid
            self.cajas[pid].loc = "linea"
            self.log("E4", f"La caja {self.cajas[pid].epc} regresa a la banda antes de la etiquetadora RFID.")
        if self.espera and not self.linea[0] and not self.linea[1] and self.tick - self.ultima_carga >= 2:
            pid = self.espera.pop(0)
            self.linea[0] = pid
            self.cajas[pid].loc = "linea"
            self.ultima_carga = self.tick
            self.flash["carga"] = "on"
        if self._linea_vacia():
            self._revisar_fin()

    # ------------------------------------- E3: lector de barras y, después, su IR
    def validar(self, codigo):
        """Devuelve (resultado, id_producto, motivo, esperada, detectada)."""
        codigo = (codigo or "").strip()
        if not codigo.isalnum() or len(codigo) < 7:
            return "FORMATO", None, f"El ID «{codigo}» no tiene el formato numeración + 6 dígitos de serie.", None, None
        prod = None
        for cod in sorted(self.por_codigo, key=len, reverse=True):
            if codigo.startswith(cod) and len(codigo) == len(cod) + 6 and codigo[len(cod):].isdigit():
                prod = self.por_codigo[cod]
                break
        if prod is None:
            return "CODIGO_DESCONOCIDO", None, f"La numeración de «{codigo}» no corresponde a ningún producto del proveedor.", None, None
        dup = self.bd.codigo_registrado(codigo)
        if dup:
            return "DUPLICADO", prod, f"El ID {codigo} ya está registrado en el paquete {dup}.", None, None
        esperada, aceptadas = self.bd.esperado_y_aceptado(self.id_rec, prod)
        if esperada is None:
            return "NO_ESPERADO", prod, f"{prod} {self.nombre(prod)} no viene en la recepción {self.folio}.", 0, aceptadas + 1
        if aceptadas >= esperada:
            return "EXCEDENTE", prod, f"Ya se aceptaron las {esperada} cajas esperadas de {prod} {self.nombre(prod)}.", esperada, aceptadas + 1
        return "OK", prod, "", esperada, aceptadas

    def _lector_barras(self, pid):
        """El lector de barras lee la etiqueta mientras la caja pasa frente a él. Si el código está
        dañado no entrega nada: eso lo descubre el IR que está después del lector."""
        c = self.cajas[pid]
        if c.id_paquete or c.lectura:
            return
        if c.legible:
            c.lectura = (c.codigo_barras, self.bd.lectura_codigo(self.folio, c.codigo_barras))
            self.flash["cam"] = "ok"
        else:
            self.flash["cam"] = "scan"

    def _ir_e3(self, pid):
        """El IR que sigue al lector confirma que pasó una caja y el sistema empareja la lectura
        que entregó el lector. Si no hubo lectura, es una caja sin código legible."""
        c = self.cajas[pid]
        if c.id_paquete or c.desvio:
            return
        self.detectadas += 1
        id_ir = self.bd.deteccion_ir("IR-E3", self.folio)
        lectura, c.lectura = c.lectura, None
        if not lectura:
            idi = self.bd.lectura_fallida(self.id_rec, self.folio, None, "SIN_LECTURA",
                                          "El IR que sigue al lector detectó una caja y el lector de barras no "
                                          "entregó ningún código.", id_evento=id_ir)
            c.desvio = {"zona": "A", "motivo": "SIN_LECTURA", "id_incidencia": idi, "leido": None, "id_producto": None}
            self.flash["ir3"] = "bad"
            self.log("E3", "El IR detectó una caja que el lector no pudo leer. Se desviará a revisión A.", "warn")
            return
        codigo, id_lectura = lectura
        res, prod, motivo, esp, det = self.validar(codigo)
        if res == "OK":
            c.id_paquete, c.epc = self.bd.lectura_ok(self.id_rec, self.folio, codigo, prod, id_lectura)
            c.id_producto_sis, c.codigo_leido = prod, codigo
            self.flash["ir3"] = "ok"
            self.log("E3", f"Lector: ID {codigo}. El IR confirma la caja: {prod} {self.nombre(prod)}. "
                           f"Paquete con EPC {c.epc}.", "ok")
        else:
            idi = self.bd.lectura_fallida(self.id_rec, self.folio, codigo, res, motivo, prod, esp, det,
                                          id_evento=id_lectura)
            c.desvio = {"zona": "A", "motivo": res, "id_incidencia": idi, "leido": codigo, "id_producto": prod}
            self.flash["ir3"] = "bad"
            self.log("E3", f"ID {codigo}: {motivo} Se desviará a revisión A.", "warn")

    def _d1(self, pid):
        c = self.cajas[pid]
        if not c.desvio or c.desvio["zona"] != "A":
            return
        self.linea[P["D1"]] = None
        c.loc = "revA"
        self.rev_a.append(pid)
        self.bd.desvio("DESV-D1", self.id_rec, self.folio, c.desvio["id_incidencia"])
        self.flash["d1"] = "on"
        self.log("E4", f"El desviador D1 manda la caja a revisión A: {MOTIVOS[c.desvio['motivo']].lower()}.", "warn")

    # ------------------------------- E5: impresora-etiquetadora RFID automática
    def _etiquetar(self, pid):
        """Una sola máquina, sin operador: imprime y codifica el tag con el EPC del paquete y lo pega
        en la caja que tiene enfrente. La falla «tag en la caja equivocada» es un desfase de la
        etiquetadora: dos cajas quedan con el tag de la otra. La máquina no se entera; lo descubre
        el lector RFID de E6."""
        c = self.cajas[pid]
        if not c.epc or c.tag:
            return
        self.bd.etiquetar_tag(self.folio, c.epc)
        if c.cruce:
            self.cruces_pend += 1
            c.cruce = False
        if c.tag_forzado:
            c.tag, c.tag_forzado = c.tag_forzado, None
            c.verdad.append(f"La etiquetadora le pegó el tag {c.tag}, que era de otra caja")
        else:
            c.tag = c.epc
            if self.cruces_pend > 0:
                for i in range(P["ETQ"] - 1, P["CAM"] - 1, -1):
                    q = self.cajas[self.linea[i]] if self.linea[i] else None
                    if q and q.epc and not q.tag_forzado and not q.tag:
                        c.tag, q.tag_forzado = q.epc, c.epc
                        self.cruces_pend -= 1
                        c.verdad.append(f"La etiquetadora le pegó el tag {q.epc}, que era de otra caja")
                        break
        self.flash["etq"] = "on"
        self.log("E5", f"La etiquetadora imprime, codifica y pega el tag {c.epc}.")

    # ----------------------------------- E6: antena RFID fija y, después, su IR
    def _lector_rfid(self, pid):
        """La antena lee el tag de la caja que pasa frente a ella. La lectura espera al IR."""
        c = self.cajas[pid]
        if c.lectura_rfid is not None:
            return
        if c.tag:
            c.lectura_rfid = (c.tag, self.bd.lectura_rfid(self.folio, c.tag))
            self.flash["rdr"] = "ok"
        else:
            c.lectura_rfid = (None, None)
            self.flash["rdr"] = "scan"

    def _ir_e6(self, pid):
        """El IR que sigue a la antena confirma la caja. Por la posición en la banda el sistema sabe
        qué EPC esperar y lo compara con lo que leyó la antena."""
        c = self.cajas[pid]
        id_ir = self.bd.deteccion_ir("IR-E6", self.folio)
        leido, id_lectura = c.lectura_rfid or (None, None)
        c.lectura_rfid = None
        esperado = c.epc
        if leido is None:
            res = "SIN_LECTURA"
        elif leido in self.leidos_rfid or (leido != esperado and self.bd.epc_confirmado(leido)):
            res = "DUPLICADO"
        elif leido != esperado:
            res = "NO_COINCIDE"
        else:
            res = "OK"
        if leido:
            self.leidos_rfid.add(leido)
        idi = self.bd.validar_rfid(self.id_rec, self.folio, id_lectura, id_ir, leido, esperado, res,
                                   c.id_paquete, c.id_producto_sis)
        if res == "OK":
            self.flash["ir6"] = "ok"
            self.log("E6", f"Antena: {leido}. El IR confirma la caja y coincide con el EPC esperado. Paquete VALIDADO.", "ok")
        else:
            c.desvio = {"zona": "B", "motivo": "RFID_" + res, "id_incidencia": idi, "leido": leido}
            self.flash["ir6"] = "bad"
            self.log("E6", f"La antena leyó {leido or 'nada'} y el IR confirmó la caja que debía ser {esperado}. "
                           "Se desviará a revisión B.", "warn")

    def _d2(self, pid):
        c = self.cajas[pid]
        if not c.desvio or c.desvio["zona"] != "B":
            return
        self.linea[P["D2"]] = None
        c.loc = "revB"
        self.rev_b.append(pid)
        self.bd.desvio("DESV-D2", self.id_rec, self.folio, c.desvio["id_incidencia"], c.id_paquete, c.id_producto_sis)
        self.flash["d2"] = "on"
        self.log("E6", f"El desviador D2 manda el paquete {c.epc} a revisión B. Queda RETENIDO en {self.cfg.UBIC_REVISION}.", "warn")

    def _al_almacen(self, pid):
        c = self.cajas[pid]
        c.loc = "almacen"
        self.bd.almacenar(self.id_rec, c.id_paquete, c.id_producto_sis)
        self.log("ALM", f"Paquete {c.epc} ({self.nombre(c.id_producto_sis)}) ALMACENADO en {self.cfg.UBIC_ALMACEN}.", "ok")

    # ------------------------------------------------------ decisiones humanas
    def resolver_a(self, pid, accion, codigo=None):
        """accion: 'capturar', 'aceptar' o 'devolver'. Devuelve (ok, mensaje)."""
        c = self.cajas[pid]
        d = c.desvio
        if accion == "devolver":
            self.bd.revision_a_devolver(d["id_incidencia"], f"{MOTIVOS[d['motivo']]}. Caja apartada para devolución.")
            self.rev_a.remove(pid)
            c.loc, c.desvio = "devuelta", None
            self.log("Rev A", "Caja apartada para devolución al proveedor.", "warn")
            self._revisar_fin()
            return True, ""
        if accion == "capturar":
            codigo = (codigo or "").strip()
            res, prod, motivo, _, _ = self.validar(codigo)
            if res != "OK":
                self.bd.revision_a_captura_invalida(self.folio, d["id_incidencia"], codigo, res, motivo, prod)
                c.desvio = dict(d, motivo=res, leido=codigo, id_producto=prod)
                self.log("Rev A", f"Captura manual de {codigo or '(vacío)'}: {motivo}", "warn")
                return False, motivo
            decision, obs = "AJUSTAR", f"ID {codigo} capturado a mano en revisión A."
        else:
            codigo, prod = d["leido"], d["id_producto"]
            decision, obs = "APROBAR", f"{MOTIVOS[d['motivo']]}: el revisor acepta la caja."
        c.id_paquete, c.epc = self.bd.revision_a_aceptar(self.id_rec, self.folio, d["id_incidencia"], codigo, prod,
                                                         decision, obs)
        c.id_producto_sis, c.codigo_leido, c.desvio = prod, codigo, None
        self.rev_a.remove(pid)
        c.loc = "reingreso"
        self.reingreso.append(pid)
        self.log("Rev A", f"{obs} Paquete {c.epc}. La caja regresa a la línea.", "ok")
        return True, ""

    def resolver_b(self, pid, accion):
        """accion: 'reetiquetar' o 'devolver'."""
        c = self.cajas[pid]
        d = c.desvio
        self.rev_b.remove(pid)
        if accion == "reetiquetar":
            self.bd.revision_b_reetiquetar(self.id_rec, self.folio, d["id_incidencia"], c.id_paquete,
                                           c.id_producto_sis, c.epc, c.codigo_barras)
            c.tag, c.loc = c.epc, "almacen"
            c.verdad.append(f"Reetiquetada en revisión con {c.epc}")
            self.log("Rev B", f"ID {c.codigo_barras} escaneado a mano. Tag {c.epc} reimpreso. Paquete ALMACENADO.", "ok")
        else:
            self.bd.revision_b_devolver(self.id_rec, d["id_incidencia"], c.id_paquete, c.id_producto_sis, c.epc)
            c.loc = "devuelta"
            self.log("Rev B", f"Paquete {c.epc} DEVUELTO al proveedor.", "warn")
        c.desvio = None
        self._revisar_fin()

    def _revisar_fin(self):
        if self.fase != "linea" or not self._linea_vacia() or self.rev_a or self.rev_b:
            return
        estado, difs = self.bd.cerrar_linea(self.id_rec, self.folio)
        self.resultado_cierre = (estado, difs)
        self.fase = "fin"
        texto = "sin diferencias" if estado == "VALIDADA" else f"con {len(difs)} diferencia(s) por producto"
        self.log("Fin", f"Línea terminada: recepción {self.folio} {estado}, {texto}.", "ok" if estado == "VALIDADA" else "warn")

    def cerrar_recepcion(self):
        if self.fase != "fin":
            return
        self.bd.cerrar_recepcion(self.id_rec, self.folio)
        self.fase = "cerrada"
        self.log("Fin", f"Recepción {self.folio} CERRADA por el operador.", "ok")

    # ------------------------------------------------------------------ venta
    def consultar_tag(self, epc):
        """Lectura del tag con el lector RFID de mano en el mostrador."""
        info = self.bd.consultar_epc(epc)
        if info:
            self.log("Venta", f"Lectura RFID de {epc}: {info['id_producto']} {info['nombre']}, "
                              f"{info['estado_validacion']}.")
        else:
            self.log("Venta", f"Lectura RFID de {epc}: el tag no está registrado en paquetes.", "warn")
        return info

    def vender(self, epc):
        folio = self.bd.registrar_venta(epc)
        for c in self.cajas.values():
            if c.epc == epc and c.loc == "almacen":
                c.loc = "vendida"
                c.verdad.append(f"Vendida con la orden {folio}")
        self.log("Venta", f"Tag {epc} vendido: el paquete pasa a VENDIDO. Orden {folio} (SURTIDO, COMPLETADA) "
                          f"y salida de {self.cfg.UBIC_ALMACEN}.", "ok")
        return folio
