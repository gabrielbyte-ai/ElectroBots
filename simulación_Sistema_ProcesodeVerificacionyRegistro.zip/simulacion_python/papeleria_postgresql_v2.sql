-- =====================================================================
-- PROYECTO: Sistema IoT de almacén - Papelería (caso de estudio Norma)
-- ARCHIVO: papeleria_postgresql_v2.sql
-- VERSION: 0.2 - Esqueleto inicial + ajustes de la simulación de la línea
-- MOTOR: PostgreSQL 13 o superior
--
-- CAMBIOS RESPECTO A LA V1:
-- a) paquetes.estado_validacion acepta VENDIDO: la caja salió del almacén
--    por una venta. Si la base ya existía con la v1, la sección 2 cambia
--    el CHECK sin borrar nada.
-- b) Datos iniciales: la numeración del proveedor Norma (codigo_proveedor
--    01 a 16) y los dispositivos IoT de la línea de recepción.
--
-- INSTRUCCIONES:
-- 1) Crear una base de datos vacía llamada: papeleria_db
-- 2) Abrir Query Tool conectado a papeleria_db en pgAdmin.
-- 3) Ejecutar este archivo completo.
--
-- PRINCIPIO DE DISEÑO:
-- PostgreSQL es la fuente principal de verdad. Firebase será una
-- representación sincronizada para consulta remota, no una segunda
-- base maestra que pueda modificar inventario por su cuenta.
-- =====================================================================

-- Zona horaria de la sesión. Configurar también la zona horaria del
-- servidor/base de datos en el despliegue definitivo.
SET TIME ZONE 'America/Mexico_City';

-- ---------------------------------------------------------------------
-- 1. CATALOGO MAESTRO
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS proveedores (
    id_proveedor       VARCHAR(20) PRIMARY KEY,
    nombre             VARCHAR(100) NOT NULL,
    activo             BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS productos (
    id_producto        VARCHAR(20) PRIMARY KEY,
    nombre             VARCHAR(120) NOT NULL,
    descripcion        TEXT,
    unidad_medida      VARCHAR(20) NOT NULL DEFAULT 'pieza',
    activo             BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Relaciona los productos que distribuye cada proveedor.
-- El mismo producto puede ser ofrecido por más de un proveedor.
CREATE TABLE IF NOT EXISTS proveedor_productos (
    id_proveedor       VARCHAR(20) NOT NULL REFERENCES proveedores(id_proveedor),
    id_producto        VARCHAR(20) NOT NULL REFERENCES productos(id_producto),
    codigo_proveedor   VARCHAR(50),
    costo_referencia   NUMERIC(14,2) CHECK (costo_referencia IS NULL OR costo_referencia >= 0),
    moneda             CHAR(3) NOT NULL DEFAULT 'MXN',
    activo             BOOLEAN NOT NULL DEFAULT TRUE,
    PRIMARY KEY (id_proveedor, id_producto),
    UNIQUE (id_proveedor, codigo_proveedor)
);

-- ---------------------------------------------------------------------
-- 2. ENTRADA: RECEPCIONES, MANIFIESTOS Y PAQUETES RFID
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS recepciones (
    id_recepcion       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    folio              VARCHAR(40) NOT NULL UNIQUE,
    id_proveedor       VARCHAR(20) NOT NULL REFERENCES proveedores(id_proveedor),
    documento_proveedor VARCHAR(60),
    fecha_recepcion    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    operador_id        VARCHAR(60),
    estado             VARCHAR(24) NOT NULL DEFAULT 'BORRADOR'
                       CHECK (estado IN ('BORRADOR', 'EN_PROCESO', 'VALIDADA', 'CON_INCIDENCIAS', 'CERRADA', 'CANCELADA')),
    observaciones      TEXT
);

-- Cantidad y costo esperados/documentados por producto en una recepción.
CREATE TABLE IF NOT EXISTS detalle_recepcion (
    id_detalle         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    id_recepcion       UUID NOT NULL REFERENCES recepciones(id_recepcion),
    id_producto        VARCHAR(20) NOT NULL REFERENCES productos(id_producto),
    cantidad_esperada  NUMERIC(14,3) NOT NULL CHECK (cantidad_esperada > 0),
    costo_unitario     NUMERIC(14,2) CHECK (costo_unitario IS NULL OR costo_unitario >= 0),
    UNIQUE (id_recepcion, id_producto)
);

-- Cada caja/paquete lleva una etiqueta RFID propia (EPC).
-- Su contenido se registra antes de pasar por el lector.
CREATE TABLE IF NOT EXISTS paquetes (
    id_paquete         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    id_recepcion       UUID NOT NULL REFERENCES recepciones(id_recepcion),
    epc_rfid           VARCHAR(128) NOT NULL UNIQUE,
    -- VENDIDO: la caja salió del almacén por una venta (orden de trabajo SURTIDO).
    estado_validacion  VARCHAR(24) NOT NULL DEFAULT 'PENDIENTE'
                       CHECK (estado_validacion IN ('PENDIENTE', 'VALIDADO', 'RETENIDO', 'ALMACENADO', 'DEVUELTO', 'VENDIDO')),
    fecha_registro     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Base creada con la v1: CREATE TABLE IF NOT EXISTS no cambia una tabla
-- que ya existe, así que aquí se reemplaza el CHECK de estado_validacion
-- por el nuevo, solo si todavía no acepta VENDIDO.
DO $$
DECLARE
    r RECORD;
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conrelid = 'paquetes'::regclass AND contype = 'c'
          AND pg_get_constraintdef(oid) LIKE '%estado_validacion%'
          AND pg_get_constraintdef(oid) LIKE '%VENDIDO%') THEN
        FOR r IN
            SELECT conname FROM pg_constraint
            WHERE conrelid = 'paquetes'::regclass AND contype = 'c'
              AND pg_get_constraintdef(oid) LIKE '%estado_validacion%'
        LOOP
            EXECUTE format('ALTER TABLE paquetes DROP CONSTRAINT %I', r.conname);
        END LOOP;
        ALTER TABLE paquetes ADD CONSTRAINT paquetes_estado_validacion_check
            CHECK (estado_validacion IN ('PENDIENTE', 'VALIDADO', 'RETENIDO', 'ALMACENADO', 'DEVUELTO', 'VENDIDO'));
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS detalle_paquete (
    id_paquete         UUID NOT NULL REFERENCES paquetes(id_paquete),
    id_producto        VARCHAR(20) NOT NULL REFERENCES productos(id_producto),
    cantidad_declarada NUMERIC(14,3) NOT NULL CHECK (cantidad_declarada > 0),
    PRIMARY KEY (id_paquete, id_producto)
);

-- Dispositivos que generan eventos (lectores, sensores, gateway, etc.).
CREATE TABLE IF NOT EXISTS dispositivos_iot (
    id_dispositivo     VARCHAR(40) PRIMARY KEY,
    tipo               VARCHAR(40) NOT NULL,
    ubicacion          VARCHAR(80),
    estado             VARCHAR(20) NOT NULL DEFAULT 'ACTIVO'
                       CHECK (estado IN ('ACTIVO', 'INACTIVO', 'MANTENIMIENTO', 'FALLA')),
    ultima_calibracion DATE,
    fecha_registro     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Registro de eventos recibidos desde IoT. id_evento lo genera el
-- gateway y permite reconocer un reenvío del mismo mensaje.
CREATE TABLE IF NOT EXISTS eventos_iot (
    id_evento              UUID PRIMARY KEY,
    id_dispositivo         VARCHAR(40) NOT NULL REFERENCES dispositivos_iot(id_dispositivo),
    epc_rfid               VARCHAR(128),
    tipo_evento            VARCHAR(40) NOT NULL,
    fecha_evento           TIMESTAMPTZ NOT NULL,
    datos_originales       JSONB,
    estado_procesamiento   VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE'
                           CHECK (estado_procesamiento IN ('PENDIENTE', 'PROCESADO', 'RECHAZADO', 'ERROR')),
    fecha_procesamiento    TIMESTAMPTZ
);

-- ---------------------------------------------------------------------
-- 3. ALMACEN: UBICACIONES, MOVIMIENTOS Y EXISTENCIAS
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ubicaciones (
    id_ubicacion       VARCHAR(20) PRIMARY KEY,
    nombre             VARCHAR(80) NOT NULL,
    tipo               VARCHAR(20) NOT NULL
                       CHECK (tipo IN ('RECEPCION', 'ALMACEN', 'CUARENTENA', 'TRANSITO')),
    activa             BOOLEAN NOT NULL DEFAULT TRUE
);

-- ---------------------------------------------------------------------
-- 4. SALIDA: ORDENES DE TRABAJO / SURTIDO
-- Se crean antes de movimientos porque los movimientos pueden
-- referenciar una orden.
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ordenes_trabajo (
    id_orden           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    folio              VARCHAR(40) NOT NULL UNIQUE,
    tipo               VARCHAR(30) NOT NULL DEFAULT 'SURTIDO'
                       CHECK (tipo IN ('SURTIDO', 'MANTENIMIENTO', 'PRODUCCION', 'SERVICIO')),
    departamento       VARCHAR(80),
    solicitante_id     VARCHAR(60),
    responsable_id     VARCHAR(60),
    prioridad          VARCHAR(15) NOT NULL DEFAULT 'MEDIA'
                       CHECK (prioridad IN ('BAJA', 'MEDIA', 'ALTA', 'CRITICA')),
    estado             VARCHAR(30) NOT NULL DEFAULT 'BORRADOR'
                       CHECK (estado IN ('BORRADOR', 'PENDIENTE_AUTORIZACION', 'AUTORIZADA', 'EN_PROCESO', 'COMPLETADA', 'CANCELADA')),
    fecha_creacion     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    fecha_cierre       TIMESTAMPTZ,
    observaciones      TEXT
);

CREATE TABLE IF NOT EXISTS detalle_orden_trabajo (
    id_detalle         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    id_orden           UUID NOT NULL REFERENCES ordenes_trabajo(id_orden),
    id_producto        VARCHAR(20) NOT NULL REFERENCES productos(id_producto),
    cantidad_solicitada NUMERIC(14,3) NOT NULL CHECK (cantidad_solicitada > 0),
    cantidad_reservada NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK (cantidad_reservada >= 0),
    cantidad_entregada NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK (cantidad_entregada >= 0),
    UNIQUE (id_orden, id_producto),
    CHECK (cantidad_reservada <= cantidad_solicitada),
    CHECK (cantidad_entregada <= cantidad_reservada)
);

-- Historial de cada movimiento físico. Las cantidades siempre son
-- positivas; origen/destino indican el sentido del movimiento.
-- Entrada: origen NULL, destino RECEPCION.
-- Almacenamiento: origen RECEPCION, destino ALMACEN.
-- Cuarentena: origen RECEPCION, destino CUARENTENA.
-- Liberación: origen CUARENTENA, destino ALMACEN.
-- Salida: origen ALMACEN, destino NULL.
CREATE TABLE IF NOT EXISTS movimientos_inventario (
    id_movimiento      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    id_producto        VARCHAR(20) NOT NULL REFERENCES productos(id_producto),
    tipo_movimiento    VARCHAR(30) NOT NULL
                       CHECK (tipo_movimiento IN ('RECEPCION', 'ALMACENAMIENTO', 'CUARENTENA', 'LIBERACION_CUARENTENA', 'SALIDA', 'DEVOLUCION', 'AJUSTE_ENTRADA', 'AJUSTE_SALIDA', 'TRANSFERENCIA')),
    cantidad           NUMERIC(14,3) NOT NULL CHECK (cantidad > 0),
    ubicacion_origen   VARCHAR(20) REFERENCES ubicaciones(id_ubicacion),
    ubicacion_destino  VARCHAR(20) REFERENCES ubicaciones(id_ubicacion),
    id_recepcion       UUID REFERENCES recepciones(id_recepcion),
    id_paquete         UUID REFERENCES paquetes(id_paquete),
    id_evento          UUID REFERENCES eventos_iot(id_evento),
    id_orden           UUID REFERENCES ordenes_trabajo(id_orden),
    fecha_movimiento   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    fecha_operativa    DATE NOT NULL DEFAULT CURRENT_DATE,
    turno              VARCHAR(30) NOT NULL DEFAULT 'UNICO',
    operador_id        VARCHAR(60),
    observaciones      TEXT,
    CHECK (ubicacion_origen IS NOT NULL OR ubicacion_destino IS NOT NULL),
    CHECK (ubicacion_origen IS DISTINCT FROM ubicacion_destino)
);

-- Saldo actual por producto y ubicación. Se actualiza en la misma
-- transacción que inserta el movimiento correspondiente.
CREATE TABLE IF NOT EXISTS existencias (
    id_producto        VARCHAR(20) NOT NULL REFERENCES productos(id_producto),
    id_ubicacion       VARCHAR(20) NOT NULL REFERENCES ubicaciones(id_ubicacion),
    cantidad           NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK (cantidad >= 0),
    cantidad_reservada NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK (cantidad_reservada >= 0),
    fecha_actualizacion TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (id_producto, id_ubicacion),
    CHECK (cantidad_reservada <= cantidad)
);

-- ---------------------------------------------------------------------
-- 5. INCIDENCIAS Y REVISION HUMANA
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS incidencias (
    id_incidencia      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    id_recepcion       UUID REFERENCES recepciones(id_recepcion),
    id_paquete         UUID REFERENCES paquetes(id_paquete),
    id_producto        VARCHAR(20) REFERENCES productos(id_producto),
    id_evento          UUID REFERENCES eventos_iot(id_evento),
    tipo_incidencia    VARCHAR(50) NOT NULL,
    severidad          VARCHAR(15) NOT NULL DEFAULT 'MEDIA'
                       CHECK (severidad IN ('BAJA', 'MEDIA', 'ALTA', 'CRITICA')),
    cantidad_esperada  NUMERIC(14,3),
    cantidad_detectada NUMERIC(14,3),
    estado             VARCHAR(25) NOT NULL DEFAULT 'PENDIENTE'
                       CHECK (estado IN ('PENDIENTE', 'EN_REVISION', 'RESUELTA', 'RECHAZADA', 'CERRADA')),
    accion_recomendada VARCHAR(40),
    motivo             TEXT NOT NULL,
    fecha_creacion     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS revisiones_humanas (
    id_revision        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    id_incidencia      UUID NOT NULL REFERENCES incidencias(id_incidencia),
    responsable_id     VARCHAR(60) NOT NULL,
    decision           VARCHAR(25) NOT NULL
                       CHECK (decision IN ('APROBAR', 'RECHAZAR', 'AJUSTAR', 'DEVOLVER', 'PENDIENTE')),
    observaciones      TEXT,
    fecha_revision     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------
-- 6. AUDITORIA Y COLA DE SINCRONIZACION HACIA FIREBASE
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS auditoria (
    id_auditoria       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entidad            VARCHAR(60) NOT NULL,
    id_registro        VARCHAR(80) NOT NULL,
    accion             VARCHAR(30) NOT NULL,
    usuario_id         VARCHAR(60),
    valor_anterior     JSONB,
    valor_nuevo        JSONB,
    fecha_evento       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    motivo             TEXT
);

-- Patrón Outbox: cada cambio que deba publicarse en Firebase se registra
-- aquí dentro de la misma transacción local. Un servicio procesa los
-- pendientes, los publica y marca el resultado.
CREATE TABLE IF NOT EXISTS sincronizacion_outbox (
    id_outbox          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entidad            VARCHAR(60) NOT NULL,
    id_registro        VARCHAR(100) NOT NULL,
    tipo_evento        VARCHAR(40) NOT NULL,
    ruta_firebase      VARCHAR(300) NOT NULL,
    payload            JSONB NOT NULL,
    estado             VARCHAR(15) NOT NULL DEFAULT 'PENDIENTE'
                       CHECK (estado IN ('PENDIENTE', 'ENVIADO', 'ERROR')),
    intentos           INTEGER NOT NULL DEFAULT 0 CHECK (intentos >= 0),
    fecha_creacion     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    fecha_envio        TIMESTAMPTZ,
    ultimo_error       TEXT
);

-- ---------------------------------------------------------------------
-- 7. VISTAS PARA CONSULTA: EXISTENCIAS Y RESUMENES
-- Los reportes se calculan desde movimientos; no se capturan de nuevo.
-- ---------------------------------------------------------------------

CREATE OR REPLACE VIEW vw_existencias_disponibles AS
SELECT
    e.id_producto,
    p.nombre AS producto,
    e.id_ubicacion,
    u.nombre AS ubicacion,
    e.cantidad AS cantidad_fisica,
    e.cantidad_reservada,
    (e.cantidad - e.cantidad_reservada) AS cantidad_disponible
FROM existencias e
JOIN productos p ON p.id_producto = e.id_producto
JOIN ubicaciones u ON u.id_ubicacion = e.id_ubicacion;

CREATE OR REPLACE VIEW vw_resumen_diario AS
SELECT
    m.fecha_operativa,
    m.turno,
    m.id_producto,
    p.nombre AS producto,
    SUM(CASE WHEN m.tipo_movimiento IN ('RECEPCION', 'DEVOLUCION', 'AJUSTE_ENTRADA') THEN m.cantidad ELSE 0 END) AS entrada,
    SUM(CASE WHEN m.tipo_movimiento = 'ALMACENAMIENTO' THEN m.cantidad ELSE 0 END) AS almacenado,
    SUM(CASE WHEN m.tipo_movimiento = 'CUARENTENA' THEN m.cantidad ELSE 0 END) AS cuarentena,
    SUM(CASE WHEN m.tipo_movimiento = 'LIBERACION_CUARENTENA' THEN m.cantidad ELSE 0 END) AS liberado_de_cuarentena,
    SUM(CASE WHEN m.tipo_movimiento IN ('SALIDA', 'AJUSTE_SALIDA') THEN m.cantidad ELSE 0 END) AS salida
FROM movimientos_inventario m
JOIN productos p ON p.id_producto = m.id_producto
GROUP BY m.fecha_operativa, m.turno, m.id_producto, p.nombre;

CREATE OR REPLACE VIEW vw_resumen_mensual AS
SELECT
    DATE_TRUNC('month', m.fecha_operativa::TIMESTAMP)::DATE AS mes,
    m.id_producto,
    p.nombre AS producto,
    SUM(CASE WHEN m.tipo_movimiento IN ('RECEPCION', 'DEVOLUCION', 'AJUSTE_ENTRADA') THEN m.cantidad ELSE 0 END) AS entrada,
    SUM(CASE WHEN m.tipo_movimiento = 'ALMACENAMIENTO' THEN m.cantidad ELSE 0 END) AS almacenado,
    SUM(CASE WHEN m.tipo_movimiento = 'CUARENTENA' THEN m.cantidad ELSE 0 END) AS cuarentena,
    SUM(CASE WHEN m.tipo_movimiento = 'LIBERACION_CUARENTENA' THEN m.cantidad ELSE 0 END) AS liberado_de_cuarentena,
    SUM(CASE WHEN m.tipo_movimiento IN ('SALIDA', 'AJUSTE_SALIDA') THEN m.cantidad ELSE 0 END) AS salida
FROM movimientos_inventario m
JOIN productos p ON p.id_producto = m.id_producto
GROUP BY DATE_TRUNC('month', m.fecha_operativa::TIMESTAMP)::DATE, m.id_producto, p.nombre;

-- ---------------------------------------------------------------------
-- 8. INDICES PARA CONSULTAS FRECUENTES
-- ---------------------------------------------------------------------

CREATE INDEX IF NOT EXISTS idx_recepciones_proveedor_fecha
    ON recepciones (id_proveedor, fecha_recepcion);

CREATE INDEX IF NOT EXISTS idx_eventos_fecha_estado
    ON eventos_iot (fecha_evento, estado_procesamiento);

CREATE INDEX IF NOT EXISTS idx_movimientos_fecha_producto
    ON movimientos_inventario (fecha_operativa, id_producto);

CREATE INDEX IF NOT EXISTS idx_movimientos_orden
    ON movimientos_inventario (id_orden);

CREATE INDEX IF NOT EXISTS idx_incidencias_estado_fecha
    ON incidencias (estado, fecha_creacion);

CREATE INDEX IF NOT EXISTS idx_outbox_estado_fecha
    ON sincronizacion_outbox (estado, fecha_creacion);

-- ---------------------------------------------------------------------
-- 9. DATOS INICIALES: PROVEEDOR NORMA, 16 PRODUCTOS Y UBICACIONES
-- Los nombres son una propuesta de catálogo inicial y pueden editarse.
-- No se inventan cantidades de inventario ni costos.
-- ---------------------------------------------------------------------

INSERT INTO proveedores (id_proveedor, nombre)
VALUES ('PROV-001', 'Norma')
ON CONFLICT (id_proveedor) DO NOTHING;

INSERT INTO productos (id_producto, nombre, unidad_medida) VALUES
('P-001', 'Lapiz', 'pieza'),
('P-002', 'Lapicero', 'pieza'),
('P-003', 'Libreta cuadros chicos', 'pieza'),
('P-004', 'Libreta cuadros grandes', 'pieza'),
('P-005', 'Libreta rayas', 'pieza'),
('P-006', 'Libreta doble raya', 'pieza'),
('P-007', 'Plumon', 'pieza'),
('P-008', 'Goma', 'pieza'),
('P-009', 'Sacapuntas', 'pieza'),
('P-010', 'Regla', 'pieza'),
('P-011', 'Colores', 'paquete'),
('P-012', 'Marcatextos', 'pieza'),
('P-013', 'Tijeras', 'pieza'),
('P-014', 'Pegamento', 'pieza'),
('P-015', 'Corrector', 'pieza'),
('P-016', 'Hojas blancas', 'paquete')
ON CONFLICT (id_producto) DO NOTHING;

INSERT INTO proveedor_productos (id_proveedor, id_producto)
SELECT 'PROV-001', id_producto
FROM productos
WHERE id_producto BETWEEN 'P-001' AND 'P-016'
ON CONFLICT (id_proveedor, id_producto) DO NOTHING;

-- Numeración del proveedor (codigo_proveedor): los 2 dígitos con los que
-- el ID de cada caja indica su contenido. P-001 -> 01 ... P-016 -> 16.
-- Solo se llena donde está vacía.
UPDATE proveedor_productos
SET codigo_proveedor = RIGHT(id_producto, 2)
WHERE id_proveedor = 'PROV-001'
  AND codigo_proveedor IS NULL
  AND id_producto ~ '^P-[0-9]{3}$';

INSERT INTO ubicaciones (id_ubicacion, nombre, tipo) VALUES
('REC-01', 'Zona de recepcion', 'RECEPCION'),
('ALM-01', 'Almacen principal', 'ALMACEN'),
('CUA-01', 'Zona de revision humana', 'CUARENTENA')
ON CONFLICT (id_ubicacion) DO NOTHING;

-- Dispositivos IoT de la línea de recepción (E1 a E6), de la zona de
-- revisión humana y del punto de venta.
INSERT INTO dispositivos_iot (id_dispositivo, tipo, ubicacion) VALUES
('IR-E1', 'SENSOR_IR', 'E1 Banda de recepción, conteo'),
('IR-E3', 'SENSOR_IR', 'E3 Línea, después del lector de barras'),
('LB-E3', 'LECTOR_CODIGO_BARRAS', 'E3 Línea principal'),
('DESV-D1', 'DESVIADOR', 'E4 Línea principal'),
('IMP-RFID-E5', 'ETIQUETADORA_RFID', 'E5 Línea principal, imprime, codifica y pega el tag'),
('IR-E6', 'SENSOR_IR', 'E6 Línea, después del lector RFID'),
('RFID-E6', 'LECTOR_RFID_FIJO', 'E6 Línea principal'),
('DESV-D2', 'DESVIADOR', 'E6 Línea principal'),
('LB-REV', 'LECTOR_CODIGO_MANO', 'Zona de revisión humana'),
('IMP-RFID-REV', 'IMPRESORA_RFID', 'Zona de revisión humana'),
('RFID-VENTA', 'LECTOR_RFID_MANO', 'Punto de venta')
ON CONFLICT (id_dispositivo) DO NOTHING;

-- Inicializar el saldo de cada producto en las tres ubicaciones con cero.
INSERT INTO existencias (id_producto, id_ubicacion, cantidad, cantidad_reservada)
SELECT p.id_producto, u.id_ubicacion, 0, 0
FROM productos p
CROSS JOIN ubicaciones u
ON CONFLICT (id_producto, id_ubicacion) DO NOTHING;

-- ---------------------------------------------------------------------
-- 10. CONSULTAS DE COMPROBACION
-- Ejecutar después del script para revisar que el catálogo se creó.
-- ---------------------------------------------------------------------

-- SELECT * FROM proveedores;
-- SELECT * FROM productos ORDER BY id_producto;
-- SELECT * FROM proveedor_productos ORDER BY id_producto;
-- SELECT * FROM ubicaciones ORDER BY id_ubicacion;
-- SELECT * FROM dispositivos_iot ORDER BY id_dispositivo;
-- SELECT * FROM vw_existencias_disponibles ORDER BY id_producto, id_ubicacion;

-- FIN DEL ESQUELETO V2
