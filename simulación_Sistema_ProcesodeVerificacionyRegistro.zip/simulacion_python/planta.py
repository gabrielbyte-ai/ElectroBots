"""Planta animada: bandas, estaciones y cajas dibujadas en un Canvas.

Flujo en forma de U: el camión (arriba a la derecha) descarga en la banda de
recepción, que corre a la izquierda hasta la zona de espera. La persona de E2
carga la línea principal, que corre a la derecha hasta el almacén. En E5 una
impresora-etiquetadora automática imprime, codifica y pega el tag RFID."""
import time

from estilo import COL, COLORES_PRODUCTO
from motor import N, P, R_IR, RN

W, H = 1080, 372            # tamaño lógico del dibujo; se escala al tamaño de la ventana

BR_X0, BR_X1, BR_Y, BR_ALTO = 222, 692, 82, 40      # banda de recepción (corre a la izquierda)
BR_DX = (BR_X1 - BR_X0) / RN
L_X0, L_X1, L_Y, L_ALTO = 26, 906, 226, 42          # línea principal (corre a la derecha)
L_DX = (L_X1 - L_X0) / N
CAJA_LINEA = 32

# Áreas donde las cajas se acomodan en cuadrícula:
#   nombre: (x0, y0, x1, y1, columnas, tamaño de caja, margen superior, título, fondo)
AREAS = {
    "espera": (14, 30, 206, 130, 7, 22, 20, "Zona de espera (E1)", COL["panel"]),
    "camion": (716, 32, 830, 128, 4, 22, 8, "", "#E9EEF0"),
    "devuelta": (14, 280, 210, 364, 7, 22, 20, "Devolución al proveedor", "#FBF0EE"),
    "revA": (220, 280, 370, 364, 5, 22, 20, "Revisión A · lectura", "#FFF7E8"),
    "reingreso": (378, 280, 448, 364, 2, 22, 20, "Reingreso", "#EEF6F9"),
    "revB": (706, 280, 870, 364, 6, 22, 20, "Revisión B · CUA-01", "#FFF7E8"),
    "almacen": (918, 172, 1072, 364, 5, 22, 20, "Almacén ALM-01", "#EEF7F1"),
}


def x_linea(i):
    return L_X0 + (i + 0.5) * L_DX


def x_rec(i):
    return BR_X1 - (i + 0.5) * BR_DX


def celda(area, i):
    x0, y0, _x1, _y1, cols, s, top, _t, _f = AREAS[area]
    paso = s + 3
    fila, col = divmod(i, cols)
    return x0 + 8 + col * paso + s / 2, y0 + top + fila * paso + s / 2, s


def capacidad(area):
    _x0, y0, _x1, y1, cols, s, top, _t, _f = AREAS[area]
    return cols * max(1, int((y1 - y0 - top - 2) // (s + 3)))


class Planta:
    def __init__(self, canvas, fuentes):
        self.cv = canvas
        self.f_base = fuentes
        self.f = dict(fuentes)
        self.prev, self.dest = {}, {}
        self.t, self.dur = 1.0, 1.0
        self.mov_rec = self.mov_lin = False
        self.escala, self.ox, self.oy = 1.0, 0.0, 0.0
        self.hits = []
        self.desbordes = {}
        self.colores = {}
        self.flash = {}

    # ------------------------------------------------------------ posiciones
    def destinos(self, m):
        d, self.desbordes = {}, {}

        def acomodar(area, pids, mas_recientes=True):
            cap = capacidad(area)
            if len(pids) > cap:
                visibles = pids[-(cap - 1):] if mas_recientes else pids[:cap - 1]
                self.desbordes[area] = (len(pids) - (cap - 1), celda(area, cap - 1))
            else:
                visibles = pids
            for i, pid in enumerate(visibles):
                d[pid] = celda(area, i)

        acomodar("camion", list(m.camion), mas_recientes=False)
        for i, pid in enumerate(m.banda_rec):
            if pid:
                d[pid] = (x_rec(i), BR_Y, 26)
        acomodar("espera", list(m.espera), mas_recientes=False)
        for i, pid in enumerate(m.linea):
            if pid:
                d[pid] = (x_linea(i), L_Y, CAJA_LINEA)
        acomodar("revA", list(m.rev_a))
        acomodar("reingreso", list(m.reingreso))
        acomodar("revB", list(m.rev_b))
        acomodar("almacen", [p for p, c in m.cajas.items() if c.loc == "almacen"])
        acomodar("devuelta", [p for p, c in m.cajas.items() if c.loc == "devuelta" and c.folio_rec == m.folio])
        return d

    def posiciones(self):
        """Posición actual (interpolada) de cada caja visible."""
        k = max(0.0, min(1.0, self.t))
        out = {}
        for pid, (x1, y1, s1) in self.dest.items():
            x0, y0, s0 = self.prev.get(pid, (x1, y1, s1))
            out[pid] = (x0 + (x1 - x0) * k, y0 + (y1 - y0) * k, s0 + (s1 - s0) * k)
        return out

    def animar(self, antes, motor, dur_ms, rec=False, lin=False):
        self.prev = antes
        self.dest = self.destinos(motor)
        self.t, self.dur = 0.0, max(1.0, float(dur_ms))
        self.mov_rec, self.mov_lin = rec, lin
        self.flash = dict(motor.flash) if (rec or lin) else {}

    def avanzar(self, dt_ms):
        """Devuelve True mientras siga animando."""
        if self.t >= 1.0:
            return False
        self.t = min(1.0, self.t + dt_ms / self.dur)
        return True

    def color_producto(self, motor, id_producto):
        if id_producto not in self.colores:
            orden = sorted(motor.catalogo)
            i = orden.index(id_producto) if id_producto in orden else len(self.colores)
            self.colores[id_producto] = COLORES_PRODUCTO[i % len(COLORES_PRODUCTO)]
        return self.colores[id_producto]

    # ------------------------------------------------------------- selección
    def caja_en(self, ex, ey):
        x = (ex - self.ox) / self.escala
        y = (ey - self.oy) / self.escala
        for pid, x0, y0, x1, y1 in reversed(self.hits):
            if x0 - 3 <= x <= x1 + 3 and y0 - 3 <= y <= y1 + 3:
                return pid
        return None

    # ---------------------------------------------------------------- dibujo
    def dibujar(self, m, verdad=False, seleccion=None):
        cv = self.cv
        cv.delete("all")
        self.hits = []
        ancho, alto = max(cv.winfo_width(), 50), max(cv.winfo_height(), 50)
        self.escala = max(0.55, min(2.0, ancho / W, alto / H))
        # Las letras del dibujo crecen y se encogen con la planta (tamaño en píxeles)
        familia = self.f_base["mini"][0]
        px = -max(7, int(round(11 * self.escala)))
        self.f = dict(self.f_base, mini=(familia, px), mini_negrita=(familia, px, "bold"))
        self.ox = max(0.0, (ancho - W * self.escala) / 2)
        self.oy = min(6.0, max(0.0, alto - H * self.escala))
        k = self.t if self.t < 1 else 1.0
        fl = self.flash if self.t < 1 else {}

        self._fondo(m)
        self._banda(BR_X0, BR_X1, BR_Y, BR_ALTO, BR_DX, k if self.mov_rec and self.t < 1 else 0, izquierda=True)
        self._chutes()
        self._banda(L_X0, L_X1, L_Y, L_ALTO, L_DX, k if self.mov_lin and self.t < 1 else 0)
        self._estaciones(m, fl)
        self._tablero(m)

        pos = self.posiciones()
        for pid, (x, y, s) in sorted(pos.items(), key=lambda it: it[1][2]):
            c = m.cajas.get(pid)
            if c is None:
                continue
            self._caja(m, c, x, y, s, verdad, pid == seleccion)
            self.hits.append((pid, x - s / 2, y - s / 2, x + s / 2, y + s / 2))
        for area, (extra, (x, y, s)) in self.desbordes.items():
            cv.create_rectangle(x - s / 2, y - s / 2, x + s / 2, y + s / 2, fill=COL["panel2"], outline=COL["linea"])
            cv.create_text(x, y, text=f"+{extra}", font=self.f["mini_negrita"], fill=COL["texto2"])

        if self.escala != 1.0:
            cv.scale("all", 0, 0, self.escala, self.escala)
        if self.ox or self.oy:
            cv.move("all", self.ox, self.oy)

    def _fondo(self, m):
        cv, f = self.cv, self.f
        cv.create_rectangle(0, 0, W, H, fill=COL["fondo"], outline="")
        for nombre, (x0, y0, x1, y1, _c, _s, _t, titulo, fondo) in AREAS.items():
            if nombre == "camion":
                continue
            cv.create_rectangle(x0, y0, x1, y1, fill=fondo, outline=COL["linea"])
            cv.create_text(x0 + 8, y0 + 10, text=titulo, anchor="w", font=f["mini_negrita"], fill=COL["texto2"])
        # Camión con la caja abierta hacia la banda
        cv.create_text(793, 18, text="Camión del proveedor", font=f["mini_negrita"], fill=COL["texto2"])
        cv.create_rectangle(712, 28, 834, 130, fill="#E9EEF0", outline=COL["rodillo"], width=2)
        cv.create_line(712, 30, 712, 128, fill=COL["fondo"], width=3)
        cv.create_polygon(834, 60, 860, 60, 874, 82, 874, 126, 834, 126, fill="#DCE4E8", outline=COL["rodillo"], width=2)
        cv.create_polygon(840, 66, 858, 66, 868, 82, 840, 82, fill=COL["panel"], outline=COL["rodillo"])
        for xr in (740, 806, 856):
            cv.create_oval(xr - 9, 124, xr + 9, 142, fill=COL["texto2"], outline="")
            cv.create_oval(xr - 4, 129, xr + 4, 137, fill=COL["linea"], outline="")
        # Leyendas de los carriles
        cv.create_text((BR_X0 + BR_X1) / 2, 50, text="E1 · Banda de recepción: el IR cuenta cada caja",
                       font=f["mini_negrita"], fill=COL["texto2"])
        cv.create_text(BR_X1 - 6, 112, text="← corre hacia la zona de espera", anchor="e", font=f["mini"],
                       fill=COL["texto2"])
        cv.create_text(L_X1 - 4, L_Y + L_ALTO / 2 + 12, text="al almacén →", anchor="e", font=f["mini"],
                       fill=COL["texto2"])
        # Simbología
        x0, y0 = 456, 280
        cv.create_rectangle(x0, y0, 700, 364, fill=COL["panel"], outline=COL["linea"])
        cv.create_text(x0 + 8, y0 + 10, text="Simbología", anchor="w", font=f["mini_negrita"], fill=COL["texto2"])
        filas = [("caja", "Caja"), ("etiqueta", "ID del proveedor"), ("danada", "Código dañado"),
                 ("tag", "Tag RFID"), ("otro", "Tag cruzado"), ("desvio", "Con incidencia")]
        for i, (tipo, texto) in enumerate(filas):
            cx = x0 + 14 + (i // 3) * 122
            cy = y0 + 28 + (i % 3) * 18
            if tipo in ("caja", "desvio"):
                cv.create_rectangle(cx - 6, cy - 6, cx + 6, cy + 6, fill=COL["kraft"],
                                    outline=COL["error"] if tipo == "desvio" else COL["kraft_borde"],
                                    width=2 if tipo == "desvio" else 1)
                if tipo == "caja":
                    cv.create_rectangle(cx - 5, cy - 5, cx + 5, cy - 2, fill=COLORES_PRODUCTO[0], outline="")
            elif tipo == "etiqueta":
                cv.create_rectangle(cx - 7, cy - 4, cx + 7, cy + 4, fill=COL["etiqueta"], outline=COL["kraft_borde"])
                for j in range(4):
                    cv.create_line(cx - 4 + j * 2.6, cy - 2, cx - 4 + j * 2.6, cy + 3, fill=COL["barras"])
            elif tipo == "danada":
                cv.create_rectangle(cx - 7, cy - 4, cx + 7, cy + 4, fill="#E4E7E9", outline=COL["kraft_borde"])
                cv.create_line(cx - 6, cy + 3, cx + 6, cy - 3, fill=COL["error"], width=2)
            else:
                otro = tipo == "otro"
                cv.create_rectangle(cx - 5, cy - 5, cx + 5, cy + 5, fill=COL["peligro"] if otro else COL["tag"],
                                    outline=COL["error"] if otro else "#FFFFFF")
            cv.create_text(cx + 12, cy, text=texto, anchor="w", font=f["mini"], fill=COL["texto"])

    def _banda(self, x0, x1, yc, alto, paso, k, izquierda=False):
        cv = self.cv
        y0, y1 = yc - alto / 2, yc + alto / 2
        cv.create_rectangle(x0, y0, x1, y1, fill=COL["banda"], outline="")
        d = paso / 2
        off = (k * paso) % d
        if izquierda:
            off = (d - off) % d
        x = x0 + off
        while x < x1:
            if x > x0 + 1:
                cv.create_line(x, y0 + 3, x, y1 - 3, fill=COL["banda_raya"])
            x += d
        cv.create_line(x0, y0, x1, y0, fill=COL["rodillo"], width=3)
        cv.create_line(x0, y1, x1, y1, fill=COL["rodillo"], width=3)
        for xr in (x0, x1):
            cv.create_oval(xr - 4, yc - alto / 2 + 2, xr + 4, yc + alto / 2 - 2, fill=COL["rodillo"], outline="")

    def _chutes(self):
        cv = self.cv
        y1 = L_Y + L_ALTO / 2
        for pos in (P["D1"], P["D2"]):
            x = x_linea(pos)
            cv.create_polygon(x - 20, y1, x + 20, y1, x + 30, 280, x - 30, 280, fill=COL["chute"], outline="")
        xr = x_linea(P["REINS"])
        cv.create_line(xr, 280, xr, y1 + 2, fill=COL["acento"], width=2, dash=(4, 3), arrow="last")

    @staticmethod
    def _color_flash(v):
        return COL["ok"] if v == "ok" else COL["error"] if v == "bad" else COL["acento"]

    def _persona(self, x, y, activa):
        cv = self.cv
        relleno = COL["ok_claro"] if activa else COL["acento_claro"]
        borde = COL["ok"] if activa else COL["acento"]
        cv.create_oval(x - 5, y - 14, x + 5, y - 4, fill=relleno, outline=borde)
        cv.create_polygon(x - 9, y + 9, x - 6, y - 2, x + 6, y - 2, x + 9, y + 9, fill=relleno, outline=borde)

    def _ir(self, x, y0, y1, estado=None):
        """Sensor IR de barrera. estado: None (sin caja), 'on' (cuenta), 'ok' o 'bad' (resultado)."""
        cv = self.cv
        cv.create_rectangle(x - 3, y0 - 7, x + 3, y0 - 1, fill=COL["ir"], outline="")
        cv.create_rectangle(x - 3, y1 + 1, x + 3, y1 + 7, fill=COL["ir"], outline="")
        if estado:
            color = COL["ok"] if estado == "ok" else COL["ir"]
            cv.create_line(x, y0, x, y1, fill=color, width=3 if estado == "bad" else 2)
        else:
            cv.create_line(x, y0, x, y1, fill=COL["ir"], dash=(3, 3))

    def _rotulo(self, x, codigo, nombre):
        self.cv.create_text(x, 146, text=codigo, font=self.f["mini_negrita"], fill=COL["acento"])
        self.cv.create_text(x, 158, text=nombre, font=self.f["mini"], fill=COL["texto2"])

    def _estaciones(self, m, fl):
        cv = self.cv
        y0, y1 = L_Y - L_ALTO / 2, L_Y + L_ALTO / 2
        # E1: IR de conteo en la banda de recepción
        xi = x_rec(R_IR) + BR_DX / 2 - 6
        self._ir(xi, BR_Y - BR_ALTO / 2, BR_Y + BR_ALTO / 2, "on" if "ir_rec" in fl else None)
        cv.create_text(xi, BR_Y + BR_ALTO / 2 + 16, text="IR E1", font=self.f["mini_negrita"], fill=COL["ir"])

        # E2: carga manual
        x = x_linea(0)
        self._rotulo(x, "E2", "Carga manual")
        self._persona(x, 186, "carga" in fl)

        # E3: lector de código de barras y, después, el IR que confirma la caja
        x = x_linea(P["CAM"])
        self._rotulo(x, "E3", "Lector de barras")
        xi = x_linea(P["IR3"])
        self._ir(xi, y0, y1, fl.get("ir3"))
        cv.create_text(xi, y1 + 14, text="IR", font=self.f["mini_negrita"], fill=COL["ir"])
        color = self._color_flash(fl.get("cam"))
        cv.create_rectangle(x - 11, y0 - 26, x + 11, y0 - 9, fill=COL["panel"],
                            outline=color if "cam" in fl else COL["texto2"], width=2 if "cam" in fl else 1)
        for j in range(5):
            cv.create_line(x - 7 + j * 3.5, y0 - 22, x - 7 + j * 3.5, y0 - 13, fill=COL["barras"], width=1 + j % 2)
        if "cam" in fl:
            for dx in (-12, 0, 12):
                cv.create_line(x, y0 - 9, x + dx, L_Y, fill=color)

        # E4: desviador D1
        self._desviador(x_linea(P["D1"]), "E4", "Desviador D1", "d1" in fl)

        # E5: impresora-etiquetadora RFID automática (imprime, codifica y pega el tag; sin operador)
        self._etiquetadora(x_linea(P["ETQ"]), y0, "etq" in fl)

        # E6: antena RFID fija y, después, el IR que confirma la caja; luego el desviador D2
        x = x_linea(P["RDR"])
        self._rotulo(x, "E6", "Lector RFID")
        xi = x_linea(P["IR6"])
        self._ir(xi, y0, y1, fl.get("ir6"))
        cv.create_text(xi, y1 + 14, text="IR", font=self.f["mini_negrita"], fill=COL["ir"])
        color = self._color_flash(fl.get("rdr"))
        act = "rdr" in fl
        cv.create_rectangle(x - 12, y0 - 26, x + 12, y0 - 11, fill=COL["panel"],
                            outline=color if act else COL["texto2"], width=2 if act else 1)
        for r in (8, 13):
            cv.create_arc(x - r, y0 - 11 - r, x + r, y0 - 11 + r, start=225, extent=90, style="arc",
                          outline=color if act else COL["linea"], width=2 if act else 1)
        self._desviador(x_linea(P["D2"]), "E6", "Desviador D2", "d2" in fl)

    def _etiquetadora(self, x, y0, activa):
        """Cuerpo de la máquina con su rollo de tags y el brazo que baja a pegar el tag sobre la caja."""
        cv = self.cv
        self._rotulo(x, "E5", "Etiquetadora RFID automática")
        borde = COL["acento"] if activa else COL["texto2"]
        cv.create_rectangle(x - 26, y0 - 33, x + 26, y0 - 12, fill=COL["panel2"], outline=borde,
                            width=2 if activa else 1)
        cv.create_oval(x - 23, y0 - 29, x - 11, y0 - 17, fill=COL["panel"], outline=borde)       # rollo de tags
        cv.create_oval(x - 19, y0 - 25, x - 15, y0 - 21, fill=borde, outline="")
        cv.create_text(x + 23, y0 - 22.5, text="RFID", anchor="e", font=self.f["mini_negrita"], fill=borde)
        if activa:      # el brazo baja con el tag recién impreso
            cv.create_line(x, y0 - 12, x, y0 - 5, fill=borde, width=3)
            cv.create_rectangle(x - 6, y0 - 7, x + 6, y0 + 1, fill=COL["tag"], outline="#FFFFFF")
        else:
            cv.create_line(x, y0 - 12, x, y0 - 8, fill=borde, width=3)
            cv.create_rectangle(x - 7, y0 - 9, x + 7, y0 - 6, fill=borde, outline="")

    def _desviador(self, x, codigo, nombre, activo):
        cv = self.cv
        self._rotulo(x, codigo, nombre)
        y0, y1 = L_Y - L_ALTO / 2, L_Y + L_ALTO / 2
        px, py = x - L_DX / 2 + 4, y0 - 3
        if activo:
            cv.create_line(px, py, x + L_DX / 2 - 4, y1 - 4, fill=COL["aviso"], width=5, capstyle="round")
        else:
            cv.create_line(px, py, x + L_DX / 2 - 2, py, fill=COL["texto2"], width=5, capstyle="round")
        cv.create_oval(px - 5, py - 5, px + 5, py + 5, fill=COL["panel"], outline=COL["texto2"], width=2)

    def _tablero(self, m):
        cv, f = self.cv, self.f
        x0, y0 = 888, 14
        cv.create_rectangle(x0, y0, 1072, 152, fill=COL["panel"], outline=COL["linea"])
        en_alm = sum(1 for c in m.cajas.values() if c.loc == "almacen" and c.folio_rec == m.folio)
        devueltas = sum(1 for c in m.cajas.values() if c.loc == "devuelta" and c.folio_rec == m.folio)
        filas = [
            ("Cajas esperadas", m.esperadas if m.folio else "—"),
            ("Contadas por el IR E1", m.conteo_ir if m.folio else "—"),
            ("Detectadas en E3", m.detectadas if m.folio else "—"),
            ("En revisión A / B", f"{len(m.rev_a)} / {len(m.rev_b)}"),
            ("Almacenadas", en_alm if m.folio else "—"),
            ("Devueltas", devueltas if m.folio else "—"),
        ]
        cv.create_text(x0 + 8, y0 + 13, text=m.folio or "Tablero de la recepción",
                       anchor="w", font=f["mini_negrita"], fill=COL["acento"])
        for i, (k, v) in enumerate(filas):
            y = y0 + 34 + i * 17
            cv.create_text(x0 + 8, y, text=k, anchor="w", font=f["mini"], fill=COL["texto2"])
            cv.create_text(1064, y, text=str(v), anchor="e", font=f["mini_negrita"], fill=COL["texto"])

    def _caja(self, m, c, x, y, s, verdad, seleccionada):
        cv = self.cv
        h = s / 2
        con_incidencia = c.desvio is not None
        cv.create_rectangle(x - h, y - h, x + h, y + h, fill=COL["kraft"],
                            outline=COL["error"] if con_incidencia else COL["kraft_borde"],
                            width=2 if con_incidencia else 1)
        franja = max(3, round(s * 0.16))
        color = self.color_producto(m, c.id_producto)
        cv.create_rectangle(x - h + 1, y - h + 1, x + h - 1, y - h + franja, fill=color, outline="")
        # Etiqueta del proveedor con el código de barras (abajo a la izquierda)
        lw, lh = s * 0.52, s * 0.32
        lx0, ly1 = x - h + 3, y + h - 3
        lx1, ly0 = lx0 + lw, ly1 - lh
        if c.legible:
            cv.create_rectangle(lx0, ly0, lx1, ly1, fill=COL["etiqueta"], outline=COL["kraft_borde"])
            n = 5 if s >= 28 else 3
            for j in range(n):
                bx = lx0 + 2 + j * (lw - 4) / (n - 1)
                cv.create_line(bx, ly0 + 2, bx, ly1 - 1, fill=COL["barras"], width=2 if j % 2 == 0 else 1)
        else:
            cv.create_rectangle(lx0, ly0, lx1, ly1, fill="#E4E7E9", outline=COL["kraft_borde"])
            cv.create_line(lx0 + 1, ly1 - 1, lx1 - 1, ly0 + 1, fill=COL["error"], width=2)
        if s >= 28:
            cv.create_text(x + h - 3, y - h + franja + 1, text=c.codigo_prov, anchor="ne",
                           font=self.f["mini_negrita"], fill=COL["texto"])
        if c.tag:
            t = max(6, s * 0.28)
            tx1, ty1 = x + h - 3, y + h - 3
            otro = verdad and c.tag != c.epc
            cv.create_rectangle(tx1 - t, ty1 - t, tx1, ty1, fill=COL["peligro"] if otro else COL["tag"],
                                outline=COL["error"] if otro else "#FFFFFF")
        if seleccionada:
            cv.create_rectangle(x - h - 4, y - h - 4, x + h + 4, y + h + 4, outline=COL["acento"], width=2, dash=(4, 2))


def ahora_ms():
    return time.perf_counter() * 1000.0
